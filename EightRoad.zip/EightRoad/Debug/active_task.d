# FIXED

active_task.o: ../active_task.c ../active_task.h ../gray_sensor.h \
 ../task1.h ../task2.h ../task3.h
../active_task.h:
../gray_sensor.h:
../task1.h:
../task2.h:
../task3.h:
