# FIXED

icm45686.o: ../icm45686.c ../icm45686.h ../app_config.h
../icm45686.h:
../app_config.h:
