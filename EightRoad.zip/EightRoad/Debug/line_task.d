# FIXED

line_task.o: ../line_task.c ../line_task.h ../task_profile.h \
 ../gray_sensor.h ../speed_control.h ../encoder.h
../line_task.h:
../task_profile.h:
../gray_sensor.h:
../speed_control.h:
../encoder.h:
