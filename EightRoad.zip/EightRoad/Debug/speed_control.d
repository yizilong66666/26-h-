# FIXED

speed_control.o: ../speed_control.c ../speed_control.h ../encoder.h \
 ../motor.h
../speed_control.h:
../encoder.h:
../motor.h:
