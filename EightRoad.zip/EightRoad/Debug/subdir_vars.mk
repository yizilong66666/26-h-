################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
SYSCFG_SRCS += \
../empty.syscfg 

C_SRCS += \
../active_task.c \
../empty.c \
./ti_msp_dl_config.c \
C:/ti/mspm0_sdk_2_11_00_07/source/ti/devices/msp/m0p/startup_system_files/ticlang/startup_mspm0g350x_ticlang.c \
../encoder.c \
../gray_sensor.c \
../icm45686.c \
../line_task.c \
../motor.c \
../oled.c \
../speed_control.c \
../task1.c \
../task2.c \
../task3.c \
../turn_control.c 

GEN_CMDS += \
./device_linker.cmd 

GEN_FILES += \
./device_linker.cmd \
./device.opt \
./ti_msp_dl_config.c 

C_DEPS += \
./active_task.d \
./empty.d \
./ti_msp_dl_config.d \
./startup_mspm0g350x_ticlang.d \
./encoder.d \
./gray_sensor.d \
./icm45686.d \
./line_task.d \
./motor.d \
./oled.d \
./speed_control.d \
./task1.d \
./task2.d \
./task3.d \
./turn_control.d 

GEN_OPTS += \
./device.opt 

OBJS += \
./active_task.o \
./empty.o \
./ti_msp_dl_config.o \
./startup_mspm0g350x_ticlang.o \
./encoder.o \
./gray_sensor.o \
./icm45686.o \
./line_task.o \
./motor.o \
./oled.o \
./speed_control.o \
./task1.o \
./task2.o \
./task3.o \
./turn_control.o 

GEN_MISC_FILES += \
./device.cmd.genlibs \
./ti_msp_dl_config.h \
./Event.dot 

OBJS__QUOTED += \
"active_task.o" \
"empty.o" \
"ti_msp_dl_config.o" \
"startup_mspm0g350x_ticlang.o" \
"encoder.o" \
"gray_sensor.o" \
"icm45686.o" \
"line_task.o" \
"motor.o" \
"oled.o" \
"speed_control.o" \
"task1.o" \
"task2.o" \
"task3.o" \
"turn_control.o" 

GEN_MISC_FILES__QUOTED += \
"device.cmd.genlibs" \
"ti_msp_dl_config.h" \
"Event.dot" 

C_DEPS__QUOTED += \
"active_task.d" \
"empty.d" \
"ti_msp_dl_config.d" \
"startup_mspm0g350x_ticlang.d" \
"encoder.d" \
"gray_sensor.d" \
"icm45686.d" \
"line_task.d" \
"motor.d" \
"oled.d" \
"speed_control.d" \
"task1.d" \
"task2.d" \
"task3.d" \
"turn_control.d" 

GEN_FILES__QUOTED += \
"device_linker.cmd" \
"device.opt" \
"ti_msp_dl_config.c" 

C_SRCS__QUOTED += \
"../active_task.c" \
"../empty.c" \
"./ti_msp_dl_config.c" \
"C:/ti/mspm0_sdk_2_11_00_07/source/ti/devices/msp/m0p/startup_system_files/ticlang/startup_mspm0g350x_ticlang.c" \
"../encoder.c" \
"../gray_sensor.c" \
"../icm45686.c" \
"../line_task.c" \
"../motor.c" \
"../oled.c" \
"../speed_control.c" \
"../task1.c" \
"../task2.c" \
"../task3.c" \
"../turn_control.c" 

SYSCFG_SRCS__QUOTED += \
"../empty.syscfg" 


