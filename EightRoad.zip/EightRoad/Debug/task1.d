# FIXED

task1.o: ../task1.c ../task1.h ../gray_sensor.h ../line_task.h \
 ../task_profile.h ../speed_control.h ../task1_config.h
../task1.h:
../gray_sensor.h:
../line_task.h:
../task_profile.h:
../speed_control.h:
../task1_config.h:
