# FIXED

task2.o: ../task2.c ../task2.h ../gray_sensor.h ../line_task.h \
 ../task_profile.h ../speed_control.h ../task2_config.h
../task2.h:
../gray_sensor.h:
../line_task.h:
../task_profile.h:
../speed_control.h:
../task2_config.h:
