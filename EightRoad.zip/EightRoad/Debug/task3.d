# FIXED

task3.o: ../task3.c ../task3.h ../gray_sensor.h ../line_task.h \
 ../task_profile.h ../speed_control.h ../task3_config.h
../task3.h:
../gray_sensor.h:
../line_task.h:
../task_profile.h:
../speed_control.h:
../task3_config.h:
