/*
 * Copyright (c) 2023, Texas Instruments Incorporated - http://www.ti.com
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ============ ti_msp_dl_config.h =============
 *  Configured MSPM0 DriverLib module declarations
 *
 *  DO NOT EDIT - This file is generated for the MSPM0G350X
 *  by the SysConfig tool.
 */
#ifndef ti_msp_dl_config_h
#define ti_msp_dl_config_h

#define CONFIG_MSPM0G350X
#define CONFIG_MSPM0G3507

#if defined(__ti_version__) || defined(__TI_COMPILER_VERSION__)
#define SYSCONFIG_WEAK __attribute__((weak))
#elif defined(__IAR_SYSTEMS_ICC__)
#define SYSCONFIG_WEAK __weak
#elif defined(__GNUC__)
#define SYSCONFIG_WEAK __attribute__((weak))
#endif

#include <ti/devices/msp/msp.h>
#include <ti/driverlib/driverlib.h>
#include <ti/driverlib/m0p/dl_core.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 *  ======== SYSCFG_DL_init ========
 *  Perform all required MSP DL initialization
 *
 *  This function should be called once at a point before any use of
 *  MSP DL.
 */


/* clang-format off */

#define POWER_STARTUP_DELAY                                                (16)


#define CPUCLK_FREQ                                                     32000000



/* Defines for MOTOR_PWM */
#define MOTOR_PWM_INST                                                     TIMA1
#define MOTOR_PWM_INST_IRQHandler                               TIMA1_IRQHandler
#define MOTOR_PWM_INST_INT_IRQN                                 (TIMA1_INT_IRQn)
#define MOTOR_PWM_INST_CLK_FREQ                                         32000000
/* GPIO defines for channel 0 */
#define GPIO_MOTOR_PWM_C0_PORT                                             GPIOB
#define GPIO_MOTOR_PWM_C0_PIN                                      DL_GPIO_PIN_4
#define GPIO_MOTOR_PWM_C0_IOMUX                                  (IOMUX_PINCM17)
#define GPIO_MOTOR_PWM_C0_IOMUX_FUNC                 IOMUX_PINCM17_PF_TIMA1_CCP0
#define GPIO_MOTOR_PWM_C0_IDX                                DL_TIMER_CC_0_INDEX
/* GPIO defines for channel 1 */
#define GPIO_MOTOR_PWM_C1_PORT                                             GPIOB
#define GPIO_MOTOR_PWM_C1_PIN                                      DL_GPIO_PIN_1
#define GPIO_MOTOR_PWM_C1_IOMUX                                  (IOMUX_PINCM13)
#define GPIO_MOTOR_PWM_C1_IOMUX_FUNC                 IOMUX_PINCM13_PF_TIMA1_CCP1
#define GPIO_MOTOR_PWM_C1_IDX                                DL_TIMER_CC_1_INDEX



/* Defines for CONTROL_TIMER */
#define CONTROL_TIMER_INST                                              (TIMG12)
#define CONTROL_TIMER_INST_IRQHandler                          TIMG12_IRQHandler
#define CONTROL_TIMER_INST_INT_IRQN                            (TIMG12_INT_IRQn)
#define CONTROL_TIMER_INST_LOAD_VALUE                                  (159999U)




/* Defines for OLED_I2C */
#define OLED_I2C_INST                                                       I2C0
#define OLED_I2C_INST_IRQHandler                                 I2C0_IRQHandler
#define OLED_I2C_INST_INT_IRQN                                     I2C0_INT_IRQn
#define OLED_I2C_BUS_SPEED_HZ                                             400000
#define GPIO_OLED_I2C_SDA_PORT                                             GPIOA
#define GPIO_OLED_I2C_SDA_PIN                                     DL_GPIO_PIN_28
#define GPIO_OLED_I2C_IOMUX_SDA                                   (IOMUX_PINCM3)
#define GPIO_OLED_I2C_IOMUX_SDA_FUNC                    IOMUX_PINCM3_PF_I2C0_SDA
#define GPIO_OLED_I2C_SCL_PORT                                             GPIOA
#define GPIO_OLED_I2C_SCL_PIN                                     DL_GPIO_PIN_31
#define GPIO_OLED_I2C_IOMUX_SCL                                   (IOMUX_PINCM6)
#define GPIO_OLED_I2C_IOMUX_SCL_FUNC                    IOMUX_PINCM6_PF_I2C0_SCL



/* Port definition for Pin Group ICM_CS */
#define ICM_CS_PORT                                                      (GPIOB)

/* Defines for CS: GPIOB.6 with pinCMx 23 on package pin 58 */
#define ICM_CS_CS_PIN                                            (DL_GPIO_PIN_6)
#define ICM_CS_CS_IOMUX                                          (IOMUX_PINCM23)
/* Port definition for Pin Group PB17_DEFAULT_LOW */
#define PB17_DEFAULT_LOW_PORT                                            (GPIOB)

/* Defines for OUTPUT_LOW: GPIOB.17 with pinCMx 43 on package pin 14 */
#define PB17_DEFAULT_LOW_OUTPUT_LOW_PIN                         (DL_GPIO_PIN_17)
#define PB17_DEFAULT_LOW_OUTPUT_LOW_IOMUX                        (IOMUX_PINCM43)
/* Defines for LEFT_IN1: GPIOA.13 with pinCMx 35 on package pin 6 */
#define CAR_GPIO_LEFT_IN1_PORT                                           (GPIOA)
#define CAR_GPIO_LEFT_IN1_PIN                                   (DL_GPIO_PIN_13)
#define CAR_GPIO_LEFT_IN1_IOMUX                                  (IOMUX_PINCM35)
/* Defines for LEFT_IN2: GPIOA.12 with pinCMx 34 on package pin 5 */
#define CAR_GPIO_LEFT_IN2_PORT                                           (GPIOA)
#define CAR_GPIO_LEFT_IN2_PIN                                   (DL_GPIO_PIN_12)
#define CAR_GPIO_LEFT_IN2_IOMUX                                  (IOMUX_PINCM34)
/* Defines for RIGHT_IN1: GPIOB.0 with pinCMx 12 on package pin 47 */
#define CAR_GPIO_RIGHT_IN1_PORT                                          (GPIOB)
#define CAR_GPIO_RIGHT_IN1_PIN                                   (DL_GPIO_PIN_0)
#define CAR_GPIO_RIGHT_IN1_IOMUX                                 (IOMUX_PINCM12)
/* Defines for RIGHT_IN2: GPIOB.16 with pinCMx 33 on package pin 4 */
#define CAR_GPIO_RIGHT_IN2_PORT                                          (GPIOB)
#define CAR_GPIO_RIGHT_IN2_PIN                                  (DL_GPIO_PIN_16)
#define CAR_GPIO_RIGHT_IN2_IOMUX                                 (IOMUX_PINCM33)
/* Defines for LEFT_ENC_A: GPIOA.15 with pinCMx 37 on package pin 8 */
#define CAR_GPIO_LEFT_ENC_A_PORT                                         (GPIOA)
// pins affected by this interrupt request:["LEFT_ENC_A","RIGHT_ENC_A"]
#define CAR_GPIO_INT_IRQN                                       (GPIOA_INT_IRQn)
#define CAR_GPIO_INT_IIDX                       (DL_INTERRUPT_GROUP1_IIDX_GPIOA)
#define CAR_GPIO_LEFT_ENC_A_IIDX                            (DL_GPIO_IIDX_DIO15)
#define CAR_GPIO_LEFT_ENC_A_PIN                                 (DL_GPIO_PIN_15)
#define CAR_GPIO_LEFT_ENC_A_IOMUX                                (IOMUX_PINCM37)
/* Defines for LEFT_ENC_B: GPIOA.16 with pinCMx 38 on package pin 9 */
#define CAR_GPIO_LEFT_ENC_B_PORT                                         (GPIOA)
#define CAR_GPIO_LEFT_ENC_B_PIN                                 (DL_GPIO_PIN_16)
#define CAR_GPIO_LEFT_ENC_B_IOMUX                                (IOMUX_PINCM38)
/* Defines for RIGHT_ENC_A: GPIOA.17 with pinCMx 39 on package pin 10 */
#define CAR_GPIO_RIGHT_ENC_A_PORT                                        (GPIOA)
#define CAR_GPIO_RIGHT_ENC_A_IIDX                           (DL_GPIO_IIDX_DIO17)
#define CAR_GPIO_RIGHT_ENC_A_PIN                                (DL_GPIO_PIN_17)
#define CAR_GPIO_RIGHT_ENC_A_IOMUX                               (IOMUX_PINCM39)
/* Defines for RIGHT_ENC_B: GPIOA.22 with pinCMx 47 on package pin 18 */
#define CAR_GPIO_RIGHT_ENC_B_PORT                                        (GPIOA)
#define CAR_GPIO_RIGHT_ENC_B_PIN                                (DL_GPIO_PIN_22)
#define CAR_GPIO_RIGHT_ENC_B_IOMUX                               (IOMUX_PINCM47)
/* Defines for S0: GPIOA.24 with pinCMx 54 on package pin 25 */
#define GRAY_GPIO_S0_PORT                                                (GPIOA)
#define GRAY_GPIO_S0_PIN                                        (DL_GPIO_PIN_24)
#define GRAY_GPIO_S0_IOMUX                                       (IOMUX_PINCM54)
/* Defines for S1: GPIOB.25 with pinCMx 56 on package pin 27 */
#define GRAY_GPIO_S1_PORT                                                (GPIOB)
#define GRAY_GPIO_S1_PIN                                        (DL_GPIO_PIN_25)
#define GRAY_GPIO_S1_IOMUX                                       (IOMUX_PINCM56)
/* Defines for S2: GPIOB.24 with pinCMx 52 on package pin 23 */
#define GRAY_GPIO_S2_PORT                                                (GPIOB)
#define GRAY_GPIO_S2_PIN                                        (DL_GPIO_PIN_24)
#define GRAY_GPIO_S2_IOMUX                                       (IOMUX_PINCM52)
/* Defines for S3: GPIOB.20 with pinCMx 48 on package pin 19 */
#define GRAY_GPIO_S3_PORT                                                (GPIOB)
#define GRAY_GPIO_S3_PIN                                        (DL_GPIO_PIN_20)
#define GRAY_GPIO_S3_IOMUX                                       (IOMUX_PINCM48)
/* Defines for S4: GPIOA.14 with pinCMx 36 on package pin 7 */
#define GRAY_GPIO_S4_PORT                                                (GPIOA)
#define GRAY_GPIO_S4_PIN                                        (DL_GPIO_PIN_14)
#define GRAY_GPIO_S4_IOMUX                                       (IOMUX_PINCM36)
/* Defines for S5: GPIOB.18 with pinCMx 44 on package pin 15 */
#define GRAY_GPIO_S5_PORT                                                (GPIOB)
#define GRAY_GPIO_S5_PIN                                        (DL_GPIO_PIN_18)
#define GRAY_GPIO_S5_IOMUX                                       (IOMUX_PINCM44)
/* Defines for S6: GPIOB.19 with pinCMx 45 on package pin 16 */
#define GRAY_GPIO_S6_PORT                                                (GPIOB)
#define GRAY_GPIO_S6_PIN                                        (DL_GPIO_PIN_19)
#define GRAY_GPIO_S6_IOMUX                                       (IOMUX_PINCM45)
/* Defines for S7: GPIOA.18 with pinCMx 40 on package pin 11 */
#define GRAY_GPIO_S7_PORT                                                (GPIOA)
#define GRAY_GPIO_S7_PIN                                        (DL_GPIO_PIN_18)
#define GRAY_GPIO_S7_IOMUX                                       (IOMUX_PINCM40)
/* Port definition for Pin Group KEY_GPIO */
#define KEY_GPIO_PORT                                                    (GPIOA)

/* Defines for KEY1: GPIOA.26 with pinCMx 59 on package pin 30 */
#define KEY_GPIO_KEY1_PIN                                       (DL_GPIO_PIN_26)
#define KEY_GPIO_KEY1_IOMUX                                      (IOMUX_PINCM59)
/* Defines for KEY2: GPIOA.25 with pinCMx 55 on package pin 26 */
#define KEY_GPIO_KEY2_PIN                                       (DL_GPIO_PIN_25)
#define KEY_GPIO_KEY2_IOMUX                                      (IOMUX_PINCM55)


/* clang-format on */

void SYSCFG_DL_init(void);
void SYSCFG_DL_initPower(void);
void SYSCFG_DL_GPIO_init(void);
void SYSCFG_DL_SYSCTL_init(void);
void SYSCFG_DL_MOTOR_PWM_init(void);
void SYSCFG_DL_CONTROL_TIMER_init(void);
void SYSCFG_DL_OLED_I2C_init(void);


bool SYSCFG_DL_saveConfiguration(void);
bool SYSCFG_DL_restoreConfiguration(void);

#ifdef __cplusplus
}
#endif

#endif /* ti_msp_dl_config_h */
