# FIXED

turn_control.o: ../turn_control.c ../turn_control.h ../app_config.h \
 ../icm45686.h ../speed_control.h
../turn_control.h:
../app_config.h:
../icm45686.h:
../speed_control.h:
