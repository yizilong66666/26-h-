# 天猛星 MSPM0G3507 12 路鱼眼循迹小车

本工程面向嘉立创“天猛星 MSPM0G3507”开发板和配套 TB6612 扩展板，不是 TI LP-MSPM0G3507 LaunchPad 工程。工程使用 MSPM0 SDK 2.11.0.07、SysConfig 1.28.0、TI Arm Clang 5.1.1 LTS 和 XDS110（SWD）。

功能包括：鱼眼 12 路灰度 UART 接收、20 kHz 双路电机 PWM、循迹 PD 与双轮速度 PI 串级控制、左右 AB 编码器二倍频测速、ICM45686 SPI 姿态与相对转角采集、SSD1306 128x64 OLED 遥测显示，以及串口失联/丢线停车保护。

逐项上电检查、完整参数范围及 PD 调整方法见 [调试与参数说明.md](调试与参数说明.md)。首次运行务必按该文档分阶段调试，不要直接把小车放到地面高速运行。

## 1. 完整接线

所有模块必须共地。接线前断电，确认电源极性后再上电。

### OLED（SSD1306，I2C 地址 0x3C）

| OLED | 天猛星 | 功能 |
|---|---|---|
| VCC | 3V3 | 建议使用 3.3 V，避免模块上拉到 5 V |
| GND | GND | 公共地 |
| SCL | PA31 / A31 | I2C0 SCL，400 kHz |
| SDA | PA28 / A28 | I2C0 SDA，400 kHz |

若 OLED 模块没有自带 I2C 上拉电阻，在 SCL、SDA 各加 4.7 kΩ 上拉到 3.3 V，不能上拉到 5 V。

### 鱼眼 12 路灰度模块

| 鱼眼模块 | 天猛星 | 说明 |
|---|---|---|
| VCC | +5V（也支持 3.3 V） | 厂商规格为 3.3–5 V |
| GND | GND | 必须共地 |
| TX | PB3 / B03 | 接 MCU UART3 RX |
| RX | PB2 / B02 | 接 MCU UART3 TX |

串口参数是 115200、8 数据位、无校验、1 停止位。厂商历程的数据帧格式为 `#000001100000!`：帧头 `#`，中间 12 个 ASCII `0/1`，帧尾 `!`，典型发送频率约 200 Hz。

### ICM45686（4 线 SPI）

| ICM45686 | 天猛星 | 功能 |
|---|---|---|
| VCC | 3V3 | 模块规格支持 3.3～5 V，本工程建议使用 3.3 V |
| GND | GND | 公共地 |
| SCL / SCLK | PB18 / B18 | SPI0 时钟 |
| SDA / MOSI | PA14 / A14 | SPI0 主机输出、传感器输入 |
| AD0 / MISO | PB19 / B19 | SPI0 传感器输出、主机输入 |
| CS | PB6 / B06 | GPIO 片选，空闲为高、通信时为低 |
| INT1、INT2 | 不接 | 当前采用 5 ms 定时轮询 |

SPI 使用 Mode 3、2 MHz。完整原理、安装方向、接线检查和调试步骤见 [ICM45686使用与调试说明.md](ICM45686使用与调试说明.md)。PB16 已用于右电机方向控制，不能作为片选。

PB17 未连接 ICM45686，工程将它配置为普通 GPIO 上电默认低电平输出。

### TB6612 电机驱动（严格按扩展板原理图）

| TB6612 | 天猛星 | 工程含义 |
|---|---|---|
| PWMA | PB4 / B04 | 左电机 20 kHz PWM，TIMA1 CCP0 |
| AIN1 | PA13 / A13 | 左电机方向 1 |
| AIN2 | PA12 / A12 | 左电机方向 2 |
| PWMB | PB1 / B01 | 右电机 20 kHz PWM，TIMA1 CCP1 |
| BIN1 | PB0 / B00 | 右电机方向 1 |
| BIN2 | PB16 / B16 | 右电机方向 2 |
| AO1、AO2 | Motor-A 电机两端 | 左电机 |
| BO1、BO2 | Motor-B 电机两端 | 右电机 |
| GND | GND | 电机电源与 MCU 共地 |

扩展板原理图中 TB6612 的 STBY 已接高电平，不需要额外 MCU 引脚。VM 是电机电源，VCC 是逻辑电源；不要把 12 V 直接接入开发板 5V/3V3 引脚。若使用配套扩展板的 12 V 输入，应由扩展板电源模块产生逻辑 5 V。

### 13 线 AB 编码器

| 编码器 | 天猛星 | Motor 插座序号 |
|---|---|---|
| 左 A 相 | PA15 / A15 | Motor-A 第 3 脚 |
| 左 B 相 | PA16 / A16 | Motor-A 第 4 脚 |
| 右 A 相 | PA17 / A17 | Motor-B 第 3 脚 |
| 右 B 相 | PA22 / A22 | Motor-B 第 4 脚 |
| 编码器 GND | GND | Motor-A/B 第 2 脚 |
| 编码器电源 | +5V | Motor-A/B 第 5 脚 |

Motor-A 第 1/6 脚是 AO1/AO2；Motor-B 第 1/6 脚是 BO2/BO1。请确认编码器 A/B 输出高电平不超过 3.3 V；若是 5 V 推挽输出，应加电平转换或分压后再接 MCU。

### XDS110（SWD）

| XDS110 | 天猛星 |
|---|---|
| SWDIO / DIO | PA19 / DIO |
| SWCLK / CLK | PA20 / CLK |
| GND | GND |
| VTREF | 3V3 |
| nRESET（可选） | RST / NRST |

目标配置文件已经选择 Texas Instruments XDS110 USB Debug Probe，SWD 时钟为 1 MHz。

## 2. 程序运行逻辑

1. `SYSCFG_DL_init()` 初始化时钟、GPIO、UART3、I2C0、TIMA1 和 TIMG12。
2. PWM 以 20 kHz 工作，`Motor_Set()`设置左右轮方向及占空比。
3. UART3 中断接收鱼眼帧；只有完整、合法的 12 位数据才更新灰度状态。
4. TIMG12 每 5 ms 产生一次控制节拍。控制器按 12 路加权位置计算误差，再用 PD 计算左右轮差速；编码器不参与 PWM 闭环，因此属于开环电机控制。
5. 左右编码器 A 相使用双边沿 GPIO 中断，读取 B 相判断方向，进行二倍频计数；A/B 输入均启用一级数字滤波。约每 100 ms 按真实时间间隔计算 RPM。
6. 8×16 字体占用 8 页显存，OLED 每次只刷新一页，约每 120 ms 完成一次全部遥测更新。
7. 上电后没有合法灰度帧不会启动电机；串口超过 100 ms 无新帧、12 路均未检测到线或 12 路全部触发时自动停车。

OLED 内容：

```text
S:000001100000    12 路灰度实时状态
L:+45% R:+42%     左右轮 PWM 百分比，正负号表示方向
VL:+20r R:-21r   左右编码器有符号转速，范围 -999～+999 RPM
SENSOR:OK         灰度通信正常；ERR 表示未收到数据或超时
```

## 3. 编码器速度计算

默认认为“13 线”是电机轴每通道 13 PPR，减速比 28:1，A 相双边沿二倍频：

```text
每个车轮输出轴一圈计数 = 13 × 28 × 2 = 728
RPM = 计数差 × 60000 / (实际间隔毫秒 × 728)
```

显示的是输出轴转速 RPM，不需要轮径。若以后需要车速：`速度(cm/s) = RPM × 轮胎周长(cm) / 60`。

## 4. 参数说明与调参

参数集中在 `app_config.h`，无需到各驱动文件中查找。

**主要调参已经集中到 `app_config.h` 最前面的“主要调参区”，并使用 `★` 标记。加入速度闭环后的完整调试步骤、参数范围和故障判断见 `速度闭环调试说明.md`。**

| 参数 | 默认值 | 含义与调整方法 |
|---|---:|---|
| `MOTOR_BASE_PWM_PERCENT` | 45 | 直线基础 PWM；先架空轮子验证，再从低到高增加 |
| `MOTOR_MAX_PWM_PERCENT` | 80 | 循迹允许的最大 PWM，限制首次调车速度 |
| `MOTOR_MIN_RUN_PWM_PERCENT` | 18 | 克服电机静摩擦的最小运行 PWM |
| `TRACK_KP` | 4 | 位置比例增益；转向迟钝就增加，蛇形严重就减小 |
| `TRACK_KD` | 7 | 误差变化抑制；用于减小摆动，过大会导致动作突变 |
| `GRAY_ACTIVE_LEVEL` | 1 | `1` 表示黑线；若 OLED 显示与实际相反改为 `0` |
| `GRAY_REVERSE_ORDER` | 0 | 左右顺序反了改为 `1` |
| `LEFT/RIGHT_MOTOR_POLARITY` | 1 | 正 PWM 却倒转时，将对应侧改为 `-1` |
| `LEFT/RIGHT_ENCODER_SIGN` | -1 / 1 | 当前左轮取反、右轮不取反；正转 RPM 符号错误时只修改对应侧 |
| `GRAY_FRAME_TIMEOUT_MS` | 100 | 鱼眼通信超时停车时间 |
| `ENCODER_PPR_MOTOR` | 13 | 电机轴每通道脉冲数；应按你的编码器铭牌修正 |
| `ENCODER_GEAR_RATIO` | 28 | 减速箱减速比 |

推荐调参顺序：基础 PWM → 电机方向 → 灰度极性和左右顺序 → KP → KD → 最大 PWM。一次只改一个参数。

## 5. 鱼眼模块标定

根据厂商 `Path Fish.pdf`：

1. 上电后长按 K1 约 1 秒进入采集模式，L1、L2 同时亮。
2. 将 12 路传感器全部放在赛道背景区，保持稳定，短按 K1；约 0.5 秒后 L1 熄灭。
3. 将 12 路传感器全部放在黑色循迹线上，保持平整，短按 K2；约 0.5 秒后 L2 熄灭。
4. 环境光或赛道改变后重新标定。标定参数保存在鱼眼模块 Flash 中。

## 6. CCS 编译、下载和调试

1. 用 CCS 打开工作区 `C:\Users\33045\workspace_ccstheia\EightRoad`，确认工程 `EightRoad` 可见。
2. 连接 XDS110 的 VTREF、GND、SWDIO、SWCLK，保持小车轮子架空。
3. 点击“生成项目”；成功产物为 `Debug/EightRoad.out`。
4. 点击“调试项目”，CCS 会通过 `targetConfigs/MSPM0G3507.ccxml` 连接 XDS110、下载并停在 `main()`。
5. 首次调试先断开电机动力电源，仅观察 OLED 的 `S:` 和 `SENSOR:OK`；再接电机电源低速测试。
6. 可在 `runLineControl()`、`Motor_Set()`、`Encoder_UpdateSpeed()` 设置断点。车轮运行时不要长时间停在断点，否则 PWM 会保持最后值。

不要手工编辑 `Debug/ti_msp_dl_config.c/.h`，它们是生成文件；引脚和外设应在 `empty.syscfg` 中修改。

## 7. 文件说明

| 文件 | 作用 |
|---|---|
| `empty.c` | 主程序、5 ms 调度和开环 PD 循迹 |
| `app_config.h` | 全部用户参数和方向修正项 |
| `motor.c/.h` | TB6612 方向与双路 PWM |
| `encoder.c/.h` | A 相双边沿二倍频计数、B 相判向与 RPM 计算 |
| `gray_sensor.c/.h` | `#` + 12 位 + `!` UART 帧解析 |
| `oled.c/.h` | SSD1306 I2C 驱动和遥测界面 |
| `empty.syscfg` | 外设、引脚、中断和 32 MHz 时钟配置 |
| `icm45686.c/.h` | ICM45686 SPI 适配、零偏校准、单位换算和相对转角积分 |
| `ICM45686/` | 商家例程随附的 TDK/InvenSense 寄存器驱动 |
| `ICM45686使用与调试说明.md` | ICM45686 接线、原理、校准、接口和调试步骤 |
| `调试与参数说明.md` | 分阶段调试步骤、完整参数范围、现象判断和 PD 调参方法 |

## 8. 常见问题

- OLED 不亮：先查 0x3C 地址、SCL/SDA 是否接反、是否共地、上拉是否到 3.3 V；部分模块地址可能是 0x3D。
- `SENSOR:ERR`：鱼眼 TX 必须接 PB3，RX 接 PB2；确认 115200 8N1，并重新进行背景/黑线采集。
- 灰度左右相反：改 `GRAY_REVERSE_ORDER`。
- 黑白状态相反：改 `GRAY_ACTIVE_LEVEL`。
- 左右轮方向不一致：先不要交换 SysConfig 引脚，改对应 `MOTOR_POLARITY`；也可检查 Motor-A/B 插头方向。
- RPM 为 0：测量 A/B 是否有 0–3.3 V 方波，检查编码器供电、公共地和插座第 3/4 脚。
- RPM 数值约为真实值的 2 倍或 4 倍：编码器厂商对“13 PPR”的定义不同，修改 `ENCODER_PPR_MOTOR` 或 `ENCODER_QUADRATURE_FACTOR`。
- 小车蛇形：先降低基础 PWM 和 KP，再逐步增加 KD。
- 高频复位/死机：检查电机电源去耦、TB6612 旁路电容、编码器电平和电机噪声；动力地与逻辑地应可靠共地但布线避免大电流经过 MCU 地线。
