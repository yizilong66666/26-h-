# Task1 / Task2 / Task3 软件任务使用说明

## 1. 当前结构

工程现在把“硬件驱动”和“比赛任务”分开：

- `app_config.h`：灰度方向、电机方向、编码器方向、轮周长、控制周期等硬件公共参数。
- `task1_config.h`：已经调通的 Task1 参数快照。
- `task2_config.h`：Task2 的独立参数试验区。
- `task3_config.h`：初始参数与 Task1 相同的第三套独立参数。
- `task1.c`、`task2.c`、`task3.c`：各自的启动、循环和静态运行状态。
- `line_task.c`：两套普通循迹任务共用的底层算法。
- `task_select.h`：当前没有按键时的软件任务选择开关。

三个任务不共用参数文件，也不共用历史误差、距离停车锁存和最终时间。

## 2. 如何选择任务

打开 `task_select.h`，修改：

```c
#define ACTIVE_TASK_ID (1U)
```

- `1U`：运行 Task1。
- `2U`：运行 Task2。
- `3U`：运行 Task3。

修改后重新编译并下载。OLED 第四行会显示 `T1`、`T2` 或 `T3`。

## 3. Task1 当前冻结内容

Task1 保留修改前的实际参数：上电等待 3 秒、全白停车、全黑继续循迹、编码器距离达到 5900 mm 后锁定停车、基础目标 85 RPM、最大 120 RPM、循迹 `KP=4.0`、`KD=1.5`。

建议后续不要改 `task1_config.h`，将它作为可随时恢复的稳定版本。

## 4. 如何调试 Task2

1. 将 `ACTIVE_TASK_ID` 改成 `2U`。
2. 先保持车轮架空，确认 OLED 第四行显示 `T2`。
3. 在 `task2_config.h` 中先把 `TASK2_MOTOR_OUTPUT_ENABLE` 设为 `0U`，检查灰度、编码器和 OLED。
4. 设置为 `1U` 后，先调基础转速和前馈 PWM。
5. 再调速度 PI：先 KP，后 KI。
6. 最后调循迹 PD：先 `TASK2_TRACK_KP`，后 `TASK2_TRACK_KD`。
7. 根据任务需要设置全白、全黑和距离停车开关。

重要参数建议按以下顺序调整：

1. `TASK2_MOTOR_OUTPUT_ENABLE`
2. `TASK2_BASE_TARGET_RPM`
3. `TASK2_SPEED_FEEDFORWARD_PWM`
4. `TASK2_SPEED_KP_NUMERATOR / DENOMINATOR`
5. `TASK2_SPEED_KI_NUMERATOR / DENOMINATOR`
6. `TASK2_TRACK_KP`
7. `TASK2_TRACK_KD`
8. `TASK2_MAX_TARGET_RPM / MIN_TARGET_RPM`
9. 三种停车条件

## 5. 修改 Task2 运行模式

当前 Task2 初始使用和 Task1 相同的普通循迹算法。如果以后 Task2 需要分阶段动作、转弯或不同停车逻辑，只修改 `Task2_Loop()` 以及 Task2 自己的状态变量即可。不要修改 `Task1_Loop()`，也不要把 Task2 的状态变量放进 Task1 文件。

目前没有加入按键初始化、按键扫描或运行时切换。以后增加按键时，只需要让按键修改任务选择并在安全停车后重新执行对应任务的 `Start`，现有 Task1/Task2 文件可以继续保留。

## 6. 计时与最终停车时间

- 计时从 MCU 上电开始，因此包含上电等待的 3 秒。
- OLED 等待阶段显示 `T1 WAIT xxx.xxxs` 或 `T2 WAIT xxx.xxxs`。
- 开始运行后时间继续累加，不会重新清零。
- 编码器距离达到对应任务的 `DISTANCE_STOP_MM` 时，在同一个 5 ms 控制周期内停车并锁存时间。
- 停车后 OLED 显示 `T1 END xxx.xxxs` 或 `T2 END xxx.xxxs`，最终时间不再增加。
- 全白停车、全黑停车、传感器掉线等非距离停车不会锁存最终时间；恢复有效运行条件后计时仍按上电时间继续。

## 7. Task2 / Task3 起步加速

Task2 和 Task3 已启用独立的起步斜坡：等待时间结束后，目标 RPM 在 `1200 ms` 内从 0 线性增加到各自的基础目标转速，避免电机从静止瞬间跳到目标速度。

- `TASK2_STARTUP_RAMP_ENABLE`、`TASK3_STARTUP_RAMP_ENABLE`：设为 `1U` 启用，设为 `0U` 恢复直接起步。
- `TASK2_STARTUP_RAMP_MS`、`TASK3_STARTUP_RAMP_MS`：斜坡时间，单位 ms；增大更柔和，但加速距离更长。
- Task1 的斜坡开关保持关闭，Task1 原有起步行为不变。
