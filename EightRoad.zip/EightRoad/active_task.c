#include "active_task.h"
#include "task1.h"
#include "task2.h"
#include "task3.h"

static uint8_t gActiveTaskId = 1U;

void ActiveTask_Start(void)
{
    if (gActiveTaskId == 1U) {
        Task1_Start();
    } else if (gActiveTaskId == 2U) {
        Task2_Start();
    } else {
        Task3_Start();
    }
}

void ActiveTask_SetId(uint8_t taskId)
{
    if (taskId < 1U || taskId > 3U) return;
    if (taskId == gActiveTaskId) return;
    gActiveTaskId = taskId;
    ActiveTask_Start();
}

void ActiveTask_Loop(const uint8_t grayStates[GRAY_SENSOR_COUNT], bool sensorOnline,
    uint32_t nowMs)
{
    if (gActiveTaskId == 1U) {
        Task1_Loop(grayStates, sensorOnline, nowMs);
    } else if (gActiveTaskId == 2U) {
        Task2_Loop(grayStates, sensorOnline, nowMs);
    } else {
        Task3_Loop(grayStates, sensorOnline, nowMs);
    }
}

uint32_t ActiveTask_GetStartupDelayMs(void)
{
    if (gActiveTaskId == 1U) return Task1_GetStartupDelayMs();
    if (gActiveTaskId == 2U) return Task2_GetStartupDelayMs();
    return Task3_GetStartupDelayMs();
}

uint8_t ActiveTask_GetId(void)
{
    return gActiveTaskId;
}

uint32_t ActiveTask_GetElapsedMs(void)
{
    if (gActiveTaskId == 1U) return Task1_GetElapsedMs();
    if (gActiveTaskId == 2U) return Task2_GetElapsedMs();
    return Task3_GetElapsedMs();
}

bool ActiveTask_IsDistanceStopped(void)
{
    if (gActiveTaskId == 1U) return Task1_IsDistanceStopped();
    if (gActiveTaskId == 2U) return Task2_IsDistanceStopped();
    return Task3_IsDistanceStopped();
}
