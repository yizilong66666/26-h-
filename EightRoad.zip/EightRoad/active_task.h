#ifndef ACTIVE_TASK_H
#define ACTIVE_TASK_H

#include "gray_sensor.h"
#include <stdbool.h>
#include <stdint.h>

void ActiveTask_Start(void);
void ActiveTask_SetId(uint8_t taskId);
void ActiveTask_Loop(const uint8_t grayStates[GRAY_SENSOR_COUNT], bool sensorOnline,
    uint32_t nowMs);
uint32_t ActiveTask_GetStartupDelayMs(void);
uint8_t ActiveTask_GetId(void);
uint32_t ActiveTask_GetElapsedMs(void);
bool ActiveTask_IsDistanceStopped(void);

#endif
