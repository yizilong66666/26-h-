#ifndef APP_CONFIG_H
#define APP_CONFIG_H

/*
 * 本文件只保存三个任务共同使用的硬件参数。
 * 循迹、转速、停车和上电等待参数请修改对应的 taskN_config.h。
 */

/*
 * ============================================================================
 * 公共硬件调参区：Task1、Task2 和 Task3 共用，必须先于任务参数完成
 * ============================================================================
 * 调试顺序：1.灰度黑白与左右 -> 2.电机前进方向 -> 3.编码器正方向
 *           -> 4.轮周长测距标定。修改这里会同时影响两个任务。
 */

/* [步骤1][★★★★★] 0=第0路在车体左侧；1=反转12路排列顺序。 */
#define GRAY_REVERSE_ORDER             (0)
/* [步骤1][★★★★★] 鱼眼返回黑线时的有效电平；黑白显示相反时在 0/1 间切换。 */
#define GRAY_ACTIVE_LEVEL              (1U)

/* [步骤2][★★★★★] 正目标转速时对应车轮必须向前；倒转就把该侧 1 改成 -1。 */
#define LEFT_MOTOR_POLARITY            (1)
#define RIGHT_MOTOR_POLARITY           (1)

/* [步骤3][★★★★★] 手动向前转动车轮时 OLED 的 RPM 必须为正，否则翻转该侧符号。 */
#define LEFT_ENCODER_SIGN              (-1)
#define RIGHT_ENCODER_SIGN             (1)

/*
 * 编码器测距标定参数：车轮在地面无打滑滚动一整圈的实际前进距离，单位 mm。
 * 当前设置为 204 mm，对应 65 mm 轮径（65 × π ≈ 204.20 mm）。精确测量时应在地面滚动 10 圈，
 * 用总距离除以 10 后填入这里，比直接用直径乘圆周率更准确。
 */
#define WHEEL_CIRCUMFERENCE_MM          (204L) /* [步骤4][★★★★] 当前对应 65 mm 轮径。 */

/*
 * ================================================================
 *                 【固定配置区：通常不需要修改】
 * ================================================================
 * 只有硬件规格、通信速度或 SysConfig 配置发生变化时才调整以下参数。
 */

/*
 * 主控制周期。必须与 empty.syscfg 中 CONTROL_TIMER 的 5 ms 周期一致。
 * 5 ms = 200 Hz，范围建议 2~10 ms；越小响应越快，但中断和运算负担越高。
 */
#define CONTROL_PERIOD_MS              (5U)
/* 每次只发送 OLED 的一页；必须取 CONTROL_PERIOD_MS 的整数倍。 */
#define OLED_REFRESH_MS                (15U) /* 每次刷新一页，8 页约 120 ms */
/* RPM 统计窗口目标值，建议 50~500 ms；越大越稳定，但显示响应越慢。 */
#define ENCODER_SPEED_PERIOD_MS        (50U)
/* 超过该时间没有合法鱼眼帧就停车。鱼眼约 5 ms 一帧，建议 50~200 ms。 */
#define GRAY_FRAME_TIMEOUT_MS          (100U)

/* 电机 PWM：SysConfig 已配置为 32 MHz / 1600 = 20 kHz。 */
#define MOTOR_PWM_PERIOD_COUNTS        (1600U)

/* 13 线编码器按电机轴每通道 13 PPR、减速比 28:1、A相双边沿二倍频计算。 */
#define ENCODER_PPR_MOTOR              (13L)
#define ENCODER_GEAR_RATIO             (28L)
#define ENCODER_QUADRATURE_FACTOR      (2L)
#define ENCODER_COUNTS_PER_WHEEL_REV   \
    (ENCODER_PPR_MOTOR * ENCODER_GEAR_RATIO * ENCODER_QUADRATURE_FACTOR)

/* OLED 显示限制，不改变内部计数；合法范围 1~999，当前三位数显示上限为 999。 */
#define ENCODER_DISPLAY_LIMIT_RPM      (999)

/* 常见 SSD1306 地址为 0x3C，少数模块为 0x3D。 */
#define OLED_I2C_ADDRESS               (0x3CU)
/*
 * ★ OLED 页面选择：
 * 1 = 显示 ICM45686 通信与陀螺仪调试数据；
 * 0 = 恢复灰度、PWM、目标转速和实际转速页面。
 */
#define OLED_SHOW_ICM45686_DEBUG         (0U)
/* 8 路 GPIO 灰度占用了 PA14/PB18/PB19，当前关闭 ICM45686 SPI。 */
#define ICM45686_ENABLE                   (0U)
/* ICM45686：SPI0 Mode 3，PB18=SCLK、PA14=MOSI、PB19=MISO、PB6=CS。 */
#define ICM45686_GYRO_RANGE_DPS           (1000L)
#define ICM45686_ACCEL_RANGE_MG           (4000L)
#define ICM45686_SAMPLE_TIMEOUT_MS        (50U)
#define ICM45686_MAX_INTEGRATION_DT_MS    (20U)
/* 200 Hz 采样：预热约 1 s，零偏平均约 2 s，期间必须静止。 */
#define ICM45686_GYRO_BIAS_WARMUP_SAMPLES (200U)
#define ICM45686_GYRO_BIAS_SAMPLES        (400U)
#define ICM45686_GYRO_ZERO_DEADBAND_RAW   (3)
/* 手动逆时针转动车身时相对角度应为正；若相反，在 1 和 -1 之间切换。 */
#define ICM45686_YAW_SIGN                 (1)

/* ★ 按角度原地转弯：高速段、接近目标后的低速段、容差、稳定时间和超时。 */
#define TURN_FAST_RPM                    (40)     /* 远离目标时轮速，降低低频反馈下的过冲。 */
#define TURN_SLOW_RPM                    (20)     /* 进入减速区后的轮速。 */
#define TURN_SLOWDOWN_MDEG               (20000L) /* 剩余 20°时减速。 */
#define TURN_TOLERANCE_MDEG              (1500L)  /* 允许 ±1.5°误差。 */
#define TURN_SETTLE_COUNT                 (10U)    /* 连续到角确认次数。 */
#define TURN_TIMEOUT_MS                   (8000U)  /* 转弯超时后立即停车。 */

#endif
