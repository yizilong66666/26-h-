/*
 * Copyright (c) 2021, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * * Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in the
 *   documentation and/or other materials provided with the distribution.
 *
 * * Neither the name of Texas Instruments Incorporated nor the names of
 *   its contributors may be used to endorse or promote products derived
 *   from this  without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES.
 */

#include "ti_msp_dl_config.h"
#include "active_task.h"
#include "app_config.h"
#include "encoder.h"
#include "gray_sensor.h"
#include "motor.h"
#include "oled.h"
#include "speed_control.h"
#include <stdbool.h>
#include <stdint.h>

/* 由 5 ms 定时器中断累加，通信超时和编码器测速使用同一时间基准。 */
volatile uint32_t gSystemTickMs;
static volatile bool gControlReady;
static volatile bool gSpeedReady;
static volatile bool gOledReady;

typedef struct {
    bool pressed;
    uint8_t debounce;
} KeyState;

static KeyState gKey1State;
static KeyState gKey2State;
static uint32_t gKey1Count;
static uint32_t gKey2Count;
static bool gRunArmed;
static uint32_t gRunArmTickMs;

static bool Key_PollPressed(GPIO_Regs *port, uint32_t pin, KeyState *state)
{
    bool pressedNow = (DL_GPIO_readPins(port, pin) == 0U);

    if (pressedNow == state->pressed) {
        state->debounce = 0U;
        return false;
    }

    if (state->debounce < 2U) {
        state->debounce++;
        return false;
    }

    state->debounce = 0U;
    state->pressed = pressedNow;
    return pressedNow;
}

int main(void)
{
    uint8_t gray[GRAY_SENSOR_COUNT] = {0};
    uint32_t frameAge = 0U;
    uint32_t startupElapsedMs;
    uint32_t runElapsedMs;
    bool frameSeen;
    bool oledOnline;
    bool startupComplete;

    SYSCFG_DL_init();

    /* 蜂鸣器由 PB17 高电平导通，始终拉低保持静音。 */
    DL_GPIO_clearPins(PB17_DEFAULT_LOW_PORT,
        PB17_DEFAULT_LOW_OUTPUT_LOW_PIN);

    Motor_Init();
    Encoder_Init();
    SpeedControl_Init();
    ActiveTask_SetId(1U);
    GraySensor_Init();
    oledOnline = OLED_Init();

    NVIC_ClearPendingIRQ(CONTROL_TIMER_INST_INT_IRQN);
    NVIC_EnableIRQ(CONTROL_TIMER_INST_INT_IRQN);
    DL_TimerG_startCounter(CONTROL_TIMER_INST);

    while (1) {
        frameSeen = GraySensor_Get(gray, &frameAge);
        startupElapsedMs = gSystemTickMs;
        startupComplete = gRunArmed &&
            (startupElapsedMs - gRunArmTickMs) >= 400U;
        runElapsedMs = startupComplete ?
            (startupElapsedMs - gRunArmTickMs - 400U +
                ActiveTask_GetStartupDelayMs()) : 0U;

        if (gControlReady) {
            gControlReady = false;
            if (Key_PollPressed(KEY_GPIO_PORT, KEY_GPIO_KEY1_PIN,
                    &gKey1State)) {
                gKey1Count = (gKey1Count % 3U) + 1U;
                ActiveTask_SetId((uint8_t)gKey1Count);
                gRunArmed = false;
                SpeedControl_Stop();
            }
            if (Key_PollPressed(KEY_GPIO_PORT, KEY_GPIO_KEY2_PIN,
                    &gKey2State)) {
                gKey2Count++;
                gRunArmed = true;
                gRunArmTickMs = gSystemTickMs;
                ActiveTask_Start();
                SpeedControl_Stop();
            }
            if (startupComplete) {
                ActiveTask_Loop(gray,
                    frameSeen && frameAge <= GRAY_FRAME_TIMEOUT_MS,
                    runElapsedMs);
            } else {
                SpeedControl_Stop();
            }
        }

        if (gSpeedReady) {
            gSpeedReady = false;
            if (!startupComplete) {
                SpeedControl_Stop();
            } else if (Encoder_UpdateSpeed()) {
                SpeedControl_Update();
            }
        }

        if (gOledReady) {
            gOledReady = false;
            if (oledOnline) {
                OLED_ShowTelemetry(Encoder_GetDistanceMm(),
                    Motor_GetLeftPWM(), Motor_GetRightPWM(),
                    Encoder_GetLeftRPM(), Encoder_GetRightRPM(),
                    frameSeen && frameAge <= GRAY_FRAME_TIMEOUT_MS,
                    startupComplete,
                    startupComplete ? ActiveTask_GetElapsedMs() :
                        (gRunArmed ? startupElapsedMs - gRunArmTickMs : 0U),
                    ActiveTask_IsDistanceStopped(), ActiveTask_GetId(),
                    gKey1Count, gKey2Count, gray);
            }
        }

        __WFI();
    }
}

void CONTROL_TIMER_INST_IRQHandler(void)
{
    static uint16_t speedElapsed;
    static uint16_t oledElapsed;

    if (DL_TimerG_getPendingInterrupt(CONTROL_TIMER_INST) ==
        DL_TIMERG_IIDX_ZERO) {
        gSystemTickMs += CONTROL_PERIOD_MS;
        gControlReady = true;
        speedElapsed += CONTROL_PERIOD_MS;
        oledElapsed += CONTROL_PERIOD_MS;

        if (speedElapsed >= ENCODER_SPEED_PERIOD_MS) {
            speedElapsed = 0U;
            gSpeedReady = true;
        }
        if (oledElapsed >= OLED_REFRESH_MS) {
            oledElapsed = 0U;
            gOledReady = true;
        }
    }
}
