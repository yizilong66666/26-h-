#include "encoder.h"
#include "app_config.h"
#include "ti_msp_dl_config.h"

extern volatile uint32_t gSystemTickMs;

/* 在 GPIO ISR 中更新，必须使用 volatile；计数允许正负和自然溢出。 */
static volatile int32_t gLeftCount;
static volatile int32_t gRightCount;
static volatile int16_t gLeftRPM;
static volatile int16_t gRightRPM;

void Encoder_Init(void)
{
    DL_GPIO_clearInterruptStatus(GPIOA, CAR_GPIO_LEFT_ENC_A_PIN |
        CAR_GPIO_LEFT_ENC_B_PIN | CAR_GPIO_RIGHT_ENC_A_PIN |
        CAR_GPIO_RIGHT_ENC_B_PIN);
    NVIC_ClearPendingIRQ(CAR_GPIO_INT_IRQN);
    NVIC_EnableIRQ(CAR_GPIO_INT_IRQN);
}

void GROUP1_IRQHandler(void)
{
    /* 仅 A 相双边沿产生中断，B 相只在此处读取用于判断方向（二倍频）。 */
    const uint32_t mask = CAR_GPIO_LEFT_ENC_A_PIN | CAR_GPIO_RIGHT_ENC_A_PIN;
    uint32_t pending = DL_GPIO_getEnabledInterruptStatus(GPIOA, mask);
    uint32_t pins = DL_GPIO_readPins(GPIOA, CAR_GPIO_LEFT_ENC_A_PIN |
        CAR_GPIO_LEFT_ENC_B_PIN | CAR_GPIO_RIGHT_ENC_A_PIN |
        CAR_GPIO_RIGHT_ENC_B_PIN);

    if (pending & CAR_GPIO_LEFT_ENC_A_PIN) {
        bool a = (pins & CAR_GPIO_LEFT_ENC_A_PIN) != 0U;
        bool b = (pins & CAR_GPIO_LEFT_ENC_B_PIN) != 0U;
        /* A、B 同电平为一个方向，不同电平为相反方向。 */
        gLeftCount += (a == b) ? 1 : -1;
    }
    if (pending & CAR_GPIO_RIGHT_ENC_A_PIN) {
        bool a = (pins & CAR_GPIO_RIGHT_ENC_A_PIN) != 0U;
        bool b = (pins & CAR_GPIO_RIGHT_ENC_B_PIN) != 0U;
        gRightCount += (a == b) ? 1 : -1;
    }
    DL_GPIO_clearInterruptStatus(GPIOA, pending);
}

bool Encoder_UpdateSpeed(void)
{
    static int32_t lastLeft;
    static int32_t lastRight;
    static uint32_t lastTick;
    int32_t left;
    int32_t right;
    uint32_t now;
    uint32_t elapsed;
    /* 复制 32 位计数和时间时短暂关中断，避免读取到一半被 GPIO ISR 修改。 */
    uint32_t primask = __get_PRIMASK();
    __disable_irq();
    left = gLeftCount;
    right = gRightCount;
    now = gSystemTickMs;
    if (!primask) __enable_irq();

    if (lastTick == 0U) {
        lastLeft = left;
        lastRight = right;
        lastTick = now;
        return false;
    }
    elapsed = now - lastTick;
    if (elapsed == 0U) return false;
    /* 使用真实时间间隔，OLED/I2C 偶尔延迟主循环也不会把 RPM 算高。 */
    gLeftRPM = (int16_t)(((int64_t)(left - lastLeft) * 60000L * LEFT_ENCODER_SIGN) /
        ((int64_t)elapsed * ENCODER_COUNTS_PER_WHEEL_REV));
    gRightRPM = (int16_t)(((int64_t)(right - lastRight) * 60000L * RIGHT_ENCODER_SIGN) /
        ((int64_t)elapsed * ENCODER_COUNTS_PER_WHEEL_REV));
    lastLeft = left;
    lastRight = right;
    lastTick = now;
    return true;
}

int32_t Encoder_GetLeftCount(void) { return gLeftCount; }
int32_t Encoder_GetRightCount(void) { return gRightCount; }
int16_t Encoder_GetLeftRPM(void) { return gLeftRPM; }
int16_t Encoder_GetRightRPM(void) { return gRightRPM; }

int32_t Encoder_GetDistanceMm(void)
{
    int32_t left;
    int32_t right;
    int64_t centerCount;
    uint32_t primask = __get_PRIMASK();

    /* 两个累计计数必须在同一个快照中读取，避免中断恰好更新其中一侧。 */
    __disable_irq();
    left = gLeftCount;
    right = gRightCount;
    if (!primask) __enable_irq();

    /*
     * 先修正左右编码器的安装方向，再取两轮平均值作为车体中心位移。
     * 正常前进为正、倒车为负；原地旋转时两轮位移相反，结果接近 0。
     */
    centerCount = ((int64_t)left * LEFT_ENCODER_SIGN +
        (int64_t)right * RIGHT_ENCODER_SIGN) / 2L;
    return (int32_t)((centerCount * WHEEL_CIRCUMFERENCE_MM) /
        ENCODER_COUNTS_PER_WHEEL_REV);
}
