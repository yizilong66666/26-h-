#ifndef ENCODER_H
#define ENCODER_H

#include <stdbool.h>
#include <stdint.h>

void Encoder_Init(void);
bool Encoder_UpdateSpeed(void);
int32_t Encoder_GetLeftCount(void);
int32_t Encoder_GetRightCount(void);
int16_t Encoder_GetLeftRPM(void);
int16_t Encoder_GetRightRPM(void);
/* 返回车体中心从上电位置开始的有符号累计位移，单位 mm。 */
int32_t Encoder_GetDistanceMm(void);

#endif
