#include "gray_sensor.h"
#include "app_config.h"
#include "ti_msp_dl_config.h"

static uint8_t readPin(GPIO_Regs *port, uint32_t pin)
{
    return (DL_GPIO_readPins(port, pin) != 0U) ? 1U : 0U;
}

void GraySensor_Init(void)
{
}

bool GraySensor_Get(uint8_t states[GRAY_SENSOR_COUNT], uint32_t *ageMs)
{
    states[0] = readPin(GRAY_GPIO_S0_PORT, GRAY_GPIO_S0_PIN);
    states[1] = readPin(GRAY_GPIO_S1_PORT, GRAY_GPIO_S1_PIN);
    states[2] = readPin(GRAY_GPIO_S2_PORT, GRAY_GPIO_S2_PIN);
    states[3] = readPin(GRAY_GPIO_S3_PORT, GRAY_GPIO_S3_PIN);
    states[4] = readPin(GRAY_GPIO_S4_PORT, GRAY_GPIO_S4_PIN);
    states[5] = readPin(GRAY_GPIO_S5_PORT, GRAY_GPIO_S5_PIN);
    states[6] = readPin(GRAY_GPIO_S6_PORT, GRAY_GPIO_S6_PIN);
    states[7] = readPin(GRAY_GPIO_S7_PORT, GRAY_GPIO_S7_PIN);

    if (ageMs != 0) *ageMs = 0U;
    return true;
}

int16_t GraySensor_CalculateError(const uint8_t states[GRAY_SENSOR_COUNT],
    uint8_t *activeCount)
{
    static const int8_t weights[GRAY_SENSOR_COUNT] = {-7,-5,-3,-1,1,3,5,7};
    int16_t sum = 0;
    uint8_t count = 0U;
    uint8_t i;

    for (i = 0U; i < GRAY_SENSOR_COUNT; i++) {
        uint8_t source = GRAY_REVERSE_ORDER ?
            (uint8_t)(GRAY_SENSOR_COUNT - 1U - i) : i;
        if (states[source] == GRAY_ACTIVE_LEVEL) {
            sum += weights[i];
            count++;
        }
    }

    *activeCount = count;
    return count ? (int16_t)(sum / count) : 0;
}
