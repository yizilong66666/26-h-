#ifndef GRAY_SENSOR_H
#define GRAY_SENSOR_H

#include <stdbool.h>
#include <stdint.h>

#define GRAY_SENSOR_COUNT 8U

void GraySensor_Init(void);
bool GraySensor_Get(uint8_t states[GRAY_SENSOR_COUNT], uint32_t *ageMs);
int16_t GraySensor_CalculateError(const uint8_t states[GRAY_SENSOR_COUNT],
    uint8_t *activeCount);

#endif
