#include "icm45686.h"
#include "app_config.h"

#if ICM45686_ENABLE
#include "ICM45686/inv_imu_driver.h"
#include "app_config.h"
#include "ti_msp_dl_config.h"
#include <math.h>
#include <string.h>

extern volatile uint32_t gSystemTickMs;

static inv_imu_device_t gDevice;
static ICM45686_Data gData;
static int64_t gGyroBiasSum[3];
static int32_t gGyroBiasRaw[3];
static int64_t gYawMdeg;
static uint32_t gBiasWarmupSamples;
static uint32_t gBiasSamples;
static uint32_t gLastIntegrationTickMs;
static bool gInitialized;

static void delayUs(uint32_t us)
{
    delay_cycles((CPUCLK_FREQ / 1000000U) * us);
}

static uint8_t spiTransfer(uint8_t value)
{
    DL_SPI_transmitDataBlocking8(ICM_SPI_INST, value);
    return DL_SPI_receiveDataBlocking8(ICM_SPI_INST);
}

static void selectDevice(void)
{
    while (!DL_SPI_isRXFIFOEmpty(ICM_SPI_INST)) {
        (void)DL_SPI_receiveData8(ICM_SPI_INST);
    }
    DL_GPIO_clearPins(ICM_CS_PORT, ICM_CS_CS_PIN);
}

static void deselectDevice(void)
{
    while (DL_SPI_isBusy(ICM_SPI_INST)) {
    }
    DL_GPIO_setPins(ICM_CS_PORT, ICM_CS_CS_PIN);
}

static int readRegisters(uint8_t reg, uint8_t *buffer, uint32_t length)
{
    uint32_t i;

    if (buffer == 0 || length == 0U) return INV_IMU_ERROR_BAD_ARG;
    selectDevice();
    (void)spiTransfer((uint8_t)(reg | 0x80U));
    for (i = 0U; i < length; i++) buffer[i] = spiTransfer(0U);
    deselectDevice();
    return 0;
}

static int writeRegisters(uint8_t reg, const uint8_t *buffer, uint32_t length)
{
    uint32_t i;

    if (buffer == 0 || length == 0U) return INV_IMU_ERROR_BAD_ARG;
    /* 按商家例程逐寄存器写入，每个事务都重新拉低和释放 CS。 */
    for (i = 0U; i < length; i++) {
        selectDevice();
        (void)spiTransfer((uint8_t)((reg + i) & 0x7FU));
        (void)spiTransfer(buffer[i]);
        deselectDevice();
    }
    return 0;
}

static int32_t wrapYawMdeg(int64_t angleMdeg)
{
    while (angleMdeg > 180000LL) angleMdeg -= 360000LL;
    while (angleMdeg < -180000LL) angleMdeg += 360000LL;
    return (int32_t)angleMdeg;
}

static int32_t rawGyroToMdps(int32_t raw)
{
    return (int32_t)(((int64_t)raw * ICM45686_GYRO_RANGE_DPS * 1000L) /
        32768L);
}

static void updateBiasAndYaw(const inv_imu_sensor_data_t *sample, uint32_t now)
{
    uint8_t axis;
    uint32_t elapsedMs;
    int32_t correctedRaw;

    if (gData.gyroBiasCalibrating) {
        if (gBiasWarmupSamples < ICM45686_GYRO_BIAS_WARMUP_SAMPLES) {
            gBiasWarmupSamples++;
            return;
        }
        for (axis = 0U; axis < 3U; axis++) {
            gGyroBiasSum[axis] += sample->gyro_data[axis];
        }
        gBiasSamples++;
        if (gBiasSamples >= ICM45686_GYRO_BIAS_SAMPLES) {
            for (axis = 0U; axis < 3U; axis++) {
                gGyroBiasRaw[axis] =
                    (int32_t)(gGyroBiasSum[axis] / (int64_t)gBiasSamples);
            }
            gData.gyroBiasCalibrating = false;
            gData.gyroBiasReady = true;
            gYawMdeg = 0;
            gData.yawMdeg = 0;
            gData.relativeYawMdeg = 0;
            gLastIntegrationTickMs = now;
        }
        return;
    }
    if (!gData.gyroBiasReady) return;

    for (axis = 0U; axis < 3U; axis++) {
        correctedRaw = (int32_t)sample->gyro_data[axis] - gGyroBiasRaw[axis];
        if (correctedRaw >= -ICM45686_GYRO_ZERO_DEADBAND_RAW &&
            correctedRaw <= ICM45686_GYRO_ZERO_DEADBAND_RAW) {
            correctedRaw = 0;
        }
        gData.gyroMdps[axis] = rawGyroToMdps(correctedRaw);
    }
    gData.gyroZMdps = gData.gyroMdps[2] * ICM45686_YAW_SIGN;

    elapsedMs = now - gLastIntegrationTickMs;
    gLastIntegrationTickMs = now;
    if (elapsedMs == 0U || elapsedMs > ICM45686_MAX_INTEGRATION_DT_MS) return;
    gYawMdeg += ((int64_t)gData.gyroZMdps * elapsedMs) / 1000LL;
    gData.yawMdeg = wrapYawMdeg(gYawMdeg);
    gData.relativeYawMdeg = gData.yawMdeg;
}

bool ICM45686_Init(void)
{
    int rc = 0;
    uint8_t whoAmI = 0U;
    drive_config0_t driveConfig = {0};

    memset(&gDevice, 0, sizeof(gDevice));
    memset(&gData, 0, sizeof(gData));
    DL_GPIO_setPins(ICM_CS_PORT, ICM_CS_CS_PIN);
    gDevice.transport.read_reg = readRegisters;
    gDevice.transport.write_reg = writeRegisters;
    gDevice.transport.serif_type = UI_SPI4;
    gDevice.transport.sleep_us = delayUs;
    delayUs(3000U);

    driveConfig.pads_spi_slew = DRIVE_CONFIG0_PADS_SPI_SLEW_TYP_10NS;
    rc |= inv_imu_write_reg(&gDevice, DRIVE_CONFIG0, 1U,
        (uint8_t *)&driveConfig);
    delayUs(2U);
    rc |= inv_imu_get_who_am_i(&gDevice, &whoAmI);
    gData.whoAmI = whoAmI;
    if (rc != 0 || whoAmI != INV_IMU_WHOAMI) {
        gData.readErrorCount++;
        return false;
    }

    rc |= inv_imu_soft_reset(&gDevice);
    rc |= inv_imu_set_accel_fsr(&gDevice,
        ACCEL_CONFIG0_ACCEL_UI_FS_SEL_4_G);
    rc |= inv_imu_set_gyro_fsr(&gDevice,
        GYRO_CONFIG0_GYRO_UI_FS_SEL_1000_DPS);
    rc |= inv_imu_set_accel_frequency(&gDevice,
        ACCEL_CONFIG0_ACCEL_ODR_200_HZ);
    rc |= inv_imu_set_gyro_frequency(&gDevice,
        GYRO_CONFIG0_GYRO_ODR_200_HZ);
    rc |= inv_imu_set_accel_ln_bw(&gDevice,
        IPREG_SYS2_REG_131_ACCEL_UI_LPFBW_DIV_4);
    rc |= inv_imu_set_gyro_ln_bw(&gDevice,
        IPREG_SYS1_REG_172_GYRO_UI_LPFBW_DIV_4);
    rc |= inv_imu_select_accel_lp_clk(&gDevice,
        SMC_CONTROL_0_ACCEL_LP_CLK_RCOSC);
    rc |= inv_imu_set_accel_mode(&gDevice, PWR_MGMT0_ACCEL_MODE_LN);
    rc |= inv_imu_set_gyro_mode(&gDevice, PWR_MGMT0_GYRO_MODE_LN);
    if (rc != 0) {
        gData.readErrorCount++;
        return false;
    }

    gInitialized = true;
    ICM45686_StartGyroBiasCalibration();
    return true;
}

void ICM45686_Update(void)
{
    uint8_t axis;
    uint32_t now = gSystemTickMs;
    inv_imu_sensor_data_t sample;

    if (!gInitialized) return;
    if (inv_imu_get_register_data(&gDevice, &sample) != 0) {
        gData.readErrorCount++;
        return;
    }

    for (axis = 0U; axis < 3U; axis++) {
        gData.accRaw[axis] = sample.accel_data[axis];
        gData.gyroRaw[axis] = sample.gyro_data[axis];
        gData.accMg[axis] = (int32_t)(((int64_t)sample.accel_data[axis] *
            ICM45686_ACCEL_RANGE_MG) / 32768L);
    }
    gData.temperatureRaw = sample.temp_data;
    gData.temperatureMdegC = 25000L +
        ((int32_t)sample.temp_data * 1000L) / 128L;
    gData.rollMdeg = (int32_t)(atan2f((float)sample.accel_data[1],
        (float)sample.accel_data[2]) * 57295.7795f);
    gData.pitchMdeg = (int32_t)(atan2f(-(float)sample.accel_data[0],
        sqrtf((float)sample.accel_data[1] * sample.accel_data[1] +
            (float)sample.accel_data[2] * sample.accel_data[2])) *
        57295.7795f);
    gData.lastSampleTickMs = now;
    gData.validSampleCount++;
    updateBiasAndYaw(&sample, now);
}

void ICM45686_StartGyroBiasCalibration(void)
{
    uint8_t axis;

    for (axis = 0U; axis < 3U; axis++) {
        gGyroBiasSum[axis] = 0;
        gGyroBiasRaw[axis] = 0;
        gData.gyroMdps[axis] = 0;
    }
    gBiasWarmupSamples = 0U;
    gBiasSamples = 0U;
    gYawMdeg = 0;
    gData.gyroZMdps = 0;
    gData.yawMdeg = 0;
    gData.relativeYawMdeg = 0;
    gData.gyroBiasReady = false;
    gData.gyroBiasCalibrating = true;
    gLastIntegrationTickMs = gSystemTickMs;
}

void ICM45686_ResetRelativeYaw(void)
{
    gYawMdeg = 0;
    gData.yawMdeg = 0;
    gData.relativeYawMdeg = 0;
    gLastIntegrationTickMs = gSystemTickMs;
}

void ICM45686_GetData(ICM45686_Data *data)
{
    uint32_t now;

    if (data == 0) return;
    *data = gData;
    now = gSystemTickMs;
    data->sampleAgeMs = (data->validSampleCount == 0U) ? UINT32_MAX :
        (now - data->lastSampleTickMs);
    data->online = gInitialized && data->validSampleCount > 0U &&
        data->sampleAgeMs <= ICM45686_SAMPLE_TIMEOUT_MS;
}

int32_t ICM45686_GetAccMg(uint8_t axis)
{
    return (axis < 3U) ? gData.accMg[axis] : 0;
}

int32_t ICM45686_GetGyroMdps(uint8_t axis)
{
    return (axis < 3U) ? gData.gyroMdps[axis] : 0;
}
#else
static ICM45686_Data gData;

bool ICM45686_Init(void)
{
    return false;
}

void ICM45686_Update(void)
{
}

void ICM45686_GetData(ICM45686_Data *data)
{
    if (data == 0) return;
    *data = gData;
    data->sampleAgeMs = UINT32_MAX;
    data->online = false;
}

void ICM45686_StartGyroBiasCalibration(void)
{
}

void ICM45686_ResetRelativeYaw(void)
{
}

int32_t ICM45686_GetAccMg(uint8_t axis)
{
    (void)axis;
    return 0;
}

int32_t ICM45686_GetGyroMdps(uint8_t axis)
{
    (void)axis;
    return 0;
}
#endif
