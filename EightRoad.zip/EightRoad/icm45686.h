#ifndef ICM45686_H
#define ICM45686_H

#include <stdbool.h>
#include <stdint.h>

typedef struct {
    int16_t accRaw[3];
    int16_t gyroRaw[3];
    int16_t temperatureRaw;
    int32_t accMg[3];
    int32_t gyroMdps[3];
    int32_t gyroZMdps;
    int32_t rollMdeg;
    int32_t pitchMdeg;
    int32_t yawMdeg;
    int32_t relativeYawMdeg;
    int32_t temperatureMdegC;
    uint32_t lastSampleTickMs;
    uint32_t sampleAgeMs;
    uint32_t validSampleCount;
    uint32_t readErrorCount;
    uint8_t whoAmI;
    bool gyroBiasReady;
    bool gyroBiasCalibrating;
    bool online;
} ICM45686_Data;

bool ICM45686_Init(void);
void ICM45686_Update(void);
void ICM45686_GetData(ICM45686_Data *data);
void ICM45686_StartGyroBiasCalibration(void);
void ICM45686_ResetRelativeYaw(void);
int32_t ICM45686_GetAccMg(uint8_t axis);
int32_t ICM45686_GetGyroMdps(uint8_t axis);

#endif
