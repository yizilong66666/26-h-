#include "line_task.h"
#include "encoder.h"
#include "gray_sensor.h"
#include "speed_control.h"

static int16_t clampTargetRPM(int16_t value, const LineTaskConfig *config,
    bool ramping)
{
    if (value > config->maxTargetRPM) value = config->maxTargetRPM;
    if (value < (ramping ? 0 : config->minTargetRPM)) {
        value = ramping ? 0 : config->minTargetRPM;
    }
    return value;
}

void LineTask_Init(LineTaskState *state, const LineTaskConfig *config)
{
    state->lastError = 0;
    state->distanceStopLatched = false;
    state->elapsedMs = 0U;
    SpeedControl_Configure(&config->speed);
    SpeedControl_Stop();
}

void LineTask_Run(LineTaskState *state, const LineTaskConfig *config,
    const uint8_t grayStates[GRAY_SENSOR_COUNT], bool sensorOnline, uint32_t nowMs)
{
    uint8_t activeCount;
    int16_t error;
    int16_t correction;
    int16_t leftTarget;
    int16_t rightTarget;
    int16_t baseTargetRPM;
    uint32_t rampElapsedMs;
    bool ramping;

    /* 未到编码器停车点时持续记录从上电开始的时间，包含上电等待时间。 */
    if (!state->distanceStopLatched) {
        state->elapsedMs = nowMs;
    }

    if (config->distanceStopEnabled && !state->distanceStopLatched &&
        Encoder_GetDistanceMm() >= config->distanceStopMm) {
        state->distanceStopLatched = true;
        state->elapsedMs = nowMs;
    }

    if (state->distanceStopLatched || !config->motorOutputEnabled ||
        !sensorOnline) {
        SpeedControl_Stop();
        state->lastError = 0;
        return;
    }

    error = GraySensor_CalculateError(grayStates, &activeCount);
    if ((activeCount == 0U && config->stopOnAllWhite) ||
        (activeCount == GRAY_SENSOR_COUNT && config->stopOnAllBlack)) {
        SpeedControl_Stop();
        state->lastError = 0;
        return;
    }

    correction = (int16_t)(config->trackKp * error +
        config->trackKd * (error - state->lastError));
    state->lastError = error;

    /* 等待结束后再启动斜坡；计时仍从上电开始，二者相互独立。 */
    rampElapsedMs = nowMs > config->startupDelayMs ?
        nowMs - config->startupDelayMs : 0U;
    ramping = config->startupRampEnabled && config->startupRampMs > 0U &&
        rampElapsedMs < config->startupRampMs;
    if (ramping) {
        baseTargetRPM = (int16_t)(((int32_t)config->baseTargetRPM *
            (int32_t)rampElapsedMs) / (int32_t)config->startupRampMs);
    } else {
        baseTargetRPM = config->baseTargetRPM;
    }

    leftTarget = clampTargetRPM(
        (int16_t)(baseTargetRPM + correction), config, ramping);
    rightTarget = clampTargetRPM(
        (int16_t)(baseTargetRPM - correction), config, ramping);
    SpeedControl_SetTargets(leftTarget, rightTarget);
}

uint32_t LineTask_GetElapsedMs(const LineTaskState *state)
{
    return state->elapsedMs;
}

bool LineTask_IsDistanceStopped(const LineTaskState *state)
{
    return state->distanceStopLatched;
}
