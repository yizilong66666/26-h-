#ifndef LINE_TASK_H
#define LINE_TASK_H

#include "task_profile.h"

void LineTask_Init(LineTaskState *state, const LineTaskConfig *config);
void LineTask_Run(LineTaskState *state, const LineTaskConfig *config,
    const uint8_t grayStates[GRAY_SENSOR_COUNT], bool sensorOnline, uint32_t nowMs);
uint32_t LineTask_GetElapsedMs(const LineTaskState *state);
bool LineTask_IsDistanceStopped(const LineTaskState *state);

#endif
