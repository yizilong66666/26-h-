#include "motor.h"
#include "app_config.h"
#include "ti_msp_dl_config.h"

/* 保存“逻辑 PWM”供 OLED 显示；正负号表示方向，绝对值表示占空比百分数。 */
static volatile int16_t gLeftPWM;
static volatile int16_t gRightPWM;

static int16_t clampPercent(int16_t value)
{
    if (value > 100) return 100;
    if (value < -100) return -100;
    return value;
}

static void setDirection(bool left, int16_t value)
{
    /* value>0 正转，value<0 反转，value=0 停止；引脚对应 TB6612 IN1/IN2。 */
    if (left) {
        if (value > 0) {
            DL_GPIO_setPins(CAR_GPIO_LEFT_IN1_PORT, CAR_GPIO_LEFT_IN1_PIN);
            DL_GPIO_clearPins(CAR_GPIO_LEFT_IN2_PORT, CAR_GPIO_LEFT_IN2_PIN);
        } else if (value < 0) {
            DL_GPIO_clearPins(CAR_GPIO_LEFT_IN1_PORT, CAR_GPIO_LEFT_IN1_PIN);
            DL_GPIO_setPins(CAR_GPIO_LEFT_IN2_PORT, CAR_GPIO_LEFT_IN2_PIN);
        } else {
            /* IN1=IN2=0：TB6612 滑行停止。 */
            DL_GPIO_clearPins(CAR_GPIO_LEFT_IN1_PORT, CAR_GPIO_LEFT_IN1_PIN);
            DL_GPIO_clearPins(CAR_GPIO_LEFT_IN2_PORT, CAR_GPIO_LEFT_IN2_PIN);
        }
    } else {
        if (value > 0) {
            DL_GPIO_setPins(CAR_GPIO_RIGHT_IN1_PORT, CAR_GPIO_RIGHT_IN1_PIN);
            DL_GPIO_clearPins(CAR_GPIO_RIGHT_IN2_PORT, CAR_GPIO_RIGHT_IN2_PIN);
        } else if (value < 0) {
            DL_GPIO_clearPins(CAR_GPIO_RIGHT_IN1_PORT, CAR_GPIO_RIGHT_IN1_PIN);
            DL_GPIO_setPins(CAR_GPIO_RIGHT_IN2_PORT, CAR_GPIO_RIGHT_IN2_PIN);
        } else {
            DL_GPIO_clearPins(CAR_GPIO_RIGHT_IN1_PORT, CAR_GPIO_RIGHT_IN1_PIN);
            DL_GPIO_clearPins(CAR_GPIO_RIGHT_IN2_PORT, CAR_GPIO_RIGHT_IN2_PIN);
        }
    }
}

static uint32_t percentToCompare(int16_t value)
{
    uint32_t duty = (uint32_t)((value < 0) ? -value : value);
    if (duty == 0U) return MOTOR_PWM_PERIOD_COUNTS;
    if (duty >= 100U) return 1U;
    /* 向下计数 PWM：0% 对应 compare=period，100% 接近 compare=0。 */
    return MOTOR_PWM_PERIOD_COUNTS -
           (MOTOR_PWM_PERIOD_COUNTS * duty) / 100U;
}

void Motor_Init(void)
{
    gLeftPWM = 0;
    gRightPWM = 0;
    Motor_Stop();
    DL_TimerA_startCounter(MOTOR_PWM_INST);
}

void Motor_Set(int16_t leftPercent, int16_t rightPercent)
{
    int16_t leftHardware;
    int16_t rightHardware;
    leftPercent = clampPercent(leftPercent);
    rightPercent = clampPercent(rightPercent);
    /* POLARITY 只修正安装方向，不改变上层“正数=车辆前进”的定义。 */
    leftHardware = (int16_t)(leftPercent * LEFT_MOTOR_POLARITY);
    rightHardware = (int16_t)(rightPercent * RIGHT_MOTOR_POLARITY);
    setDirection(true, leftHardware);
    setDirection(false, rightHardware);
    DL_TimerA_setCaptureCompareValue(
        MOTOR_PWM_INST, percentToCompare(leftHardware), GPIO_MOTOR_PWM_C0_IDX);
    DL_TimerA_setCaptureCompareValue(
        MOTOR_PWM_INST, percentToCompare(rightHardware), GPIO_MOTOR_PWM_C1_IDX);
    gLeftPWM = leftPercent;
    gRightPWM = rightPercent;
}

void Motor_Stop(void) { Motor_Set(0, 0); }
int16_t Motor_GetLeftPWM(void) { return gLeftPWM; }
int16_t Motor_GetRightPWM(void) { return gRightPWM; }
