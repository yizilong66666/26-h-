#ifndef MOTOR_H
#define MOTOR_H

#include <stdint.h>

void Motor_Init(void);
void Motor_Set(int16_t leftPercent, int16_t rightPercent);
void Motor_Stop(void);
int16_t Motor_GetLeftPWM(void);
int16_t Motor_GetRightPWM(void);

#endif
