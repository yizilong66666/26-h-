#include "oled.h"
#include "app_config.h"
#include "OLED_Font.h"
#include "ti_msp_dl_config.h"
#include <stdio.h>
#include <string.h>

/* SSD1306 128x64 一共有 8 页显存。即使只显示 4 行，也必须在上电时清空全�?8 页�?*/
static uint8_t gFrameBuffer[128U * 8U];
static uint8_t gRefreshPage;
static uint8_t gOledAddress = OLED_I2C_ADDRESS;

static bool i2cWrite(const uint8_t *data, uint8_t length)
{
    uint32_t timeout = 100000U;
    DL_I2C_flushControllerTXFIFO(OLED_I2C_INST);
    DL_I2C_fillControllerTXFIFO(OLED_I2C_INST, data, length);
    while (!(DL_I2C_getControllerStatus(OLED_I2C_INST) &
             DL_I2C_CONTROLLER_STATUS_IDLE)) {
        if (--timeout == 0U) return false;
    }
    DL_I2C_startControllerTransfer(OLED_I2C_INST, gOledAddress,
        DL_I2C_CONTROLLER_DIRECTION_TX, length);
    /* MSPM0 I2C_ERR_13：启动后至少等待 3 �?I2C 功能时钟�?*/
    delay_cycles(32U);
    timeout = 100000U;
    while (DL_I2C_getControllerStatus(OLED_I2C_INST) &
           DL_I2C_CONTROLLER_STATUS_BUSY) {
        if (--timeout == 0U) return false;
    }
    return !(DL_I2C_getControllerStatus(OLED_I2C_INST) &
             DL_I2C_CONTROLLER_STATUS_ERROR);
}

static bool writeCommand(uint8_t command)
{
    uint8_t packet[2] = {0x00U, command};
    return i2cWrite(packet, 2U);
}

#if 0
/* 旧的 5x7 精简字库保留在此处仅供对照，实际显示已改�?8x16 字库�?*/
static const uint8_t *glyph(char c)
{
    static const uint8_t blank[5] = {0,0,0,0,0};
    static const uint8_t unknown[5] = {2,1,0x51,9,6};
    static const uint8_t digit[10][5] = {
        {0x3E,0x51,0x49,0x45,0x3E},{0,0x42,0x7F,0x40,0},
        {0x42,0x61,0x51,0x49,0x46},{0x21,0x41,0x45,0x4B,0x31},
        {0x18,0x14,0x12,0x7F,0x10},{0x27,0x45,0x45,0x45,0x39},
        {0x3C,0x4A,0x49,0x49,0x30},{1,0x71,9,5,3},
        {0x36,0x49,0x49,0x49,0x36},{6,0x49,0x49,0x29,0x1E}
    };
    static const uint8_t colon[5] = {0,0x36,0x36,0,0};
    static const uint8_t plus[5]  = {8,8,0x3E,8,8};
    static const uint8_t minus[5] = {8,8,8,8,8};
    static const uint8_t percent[5] = {0x63,0x13,8,0x64,0x63};
    static const uint8_t A[5]={0x7E,0x11,0x11,0x11,0x7E};
    static const uint8_t F[5]={0x7F,9,9,9,1};
    static const uint8_t G[5]={0x3E,0x41,0x49,0x49,0x7A};
    static const uint8_t K[5]={0x7F,8,0x14,0x22,0x41};
    static const uint8_t E[5]={0x7F,0x49,0x49,0x49,0x41};
    static const uint8_t N[5]={0x7F,2,4,8,0x7F};
    static const uint8_t O[5]={0x3E,0x41,0x41,0x41,0x3E};
    static const uint8_t P[5]={0x7F,9,9,9,6};
    static const uint8_t R[5]={0x7F,9,0x19,0x29,0x46};
    static const uint8_t S[5]={0x46,0x49,0x49,0x49,0x31};
    static const uint8_t T[5]={1,1,0x7F,1,1};
    static const uint8_t U[5]={0x3F,0x40,0x40,0x40,0x3F};
    static const uint8_t V[5]={0x1F,0x20,0x40,0x20,0x1F};
    static const uint8_t lowerR[5]={0x7C,8,4,4,8};
    if (c >= '0' && c <= '9') return digit[c - '0'];
    if (c == ' ') return blank;
    if (c == ':') return colon;
    if (c == '+') return plus;
    if (c == '-') return minus;
    if (c == '%') return percent;
    switch (c) {
        case 'A': return A; case 'E': return E; case 'F': return F;
        case 'G': return G; case 'K': return K; case 'N': return N;
        case 'O': return O; case 'P': return P; case 'R': return R;
        case 'S': return S; case 'T': return T; case 'U': return U;
        case 'V': return V; case 'r': return lowerR;
        default: return unknown;
    }
}

static void drawString(uint8_t page, uint8_t x, const char *text)
{
    uint8_t i;
    while (*text && x <= 122U && page < 4U) {
        const uint8_t *font = glyph(*text++);
        for (i = 0U; i < 5U; i++) gFrameBuffer[page * 128U + x++] = font[i];
        gFrameBuffer[page * 128U + x++] = 0U;
    }
}
#endif

/* 使用厂商示例中的 8x16 ASCII 字库；一行占�?SSD1306 的两个页�?*/
static void drawString16(uint8_t line, uint8_t column, const char *text)
{
    uint8_t x = (uint8_t)(column * 8U);
    uint8_t upperPage = (uint8_t)(line * 2U);
    uint8_t i;
    while (*text && x <= 120U && line < 4U) {
        uint8_t ch = (uint8_t)*text++;
        if (ch < ' ' || ch > '~') ch = '?';
        for (i = 0U; i < 8U; i++) {
            gFrameBuffer[upperPage * 128U + x + i] =
                OLED_F8x16[(uint16_t)(ch - ' ') * 16U + i];
            gFrameBuffer[(upperPage + 1U) * 128U + x + i] =
                OLED_F8x16[(uint16_t)(ch - ' ') * 16U + i + 8U];
        }
        x = (uint8_t)(x + 8U);
    }
}

static bool flushPage(uint8_t page)
{
    uint8_t x;
    uint8_t packet[8];
    if (!writeCommand((uint8_t)(0xB0U | page)) ||
        !writeCommand(0x00U) || !writeCommand(0x10U)) return false;
    packet[0] = 0x40U;
    for (x = 0U; x < 128U; x = (uint8_t)(x + 7U)) {
        uint8_t n = (uint8_t)((128U - x > 7U) ? 7U : (128U - x));
        uint8_t i;
        for (i = 0U; i < n; i++) packet[i + 1U] = gFrameBuffer[page * 128U + x + i];
        if (!i2cWrite(packet, (uint8_t)(n + 1U))) return false;
    }
    return true;
}

bool OLED_Init(void)
{
    static const uint8_t commands[] = {
        0xAE,0xD5,0x80,0xA8,0x3F,0xD3,0x00,0x40,0xA1,0xC8,
        0xDA,0x12,0x81,0xCF,0xD9,0xF1,0xDB,0x30,0xA4,0xA6,
        0x8D,0x14,0xAF
    };
    static const uint8_t addresses[] = {0x3CU, 0x3DU};
    uint8_t addressIndex;
    uint8_t i;
    delay_cycles(CPUCLK_FREQ / 10U); /* OLED 上电稳定�?100 ms�?*/
    for (addressIndex = 0U; addressIndex < sizeof(addresses); addressIndex++) {
        gOledAddress = addresses[addressIndex];
        for (i = 0U; i < sizeof(commands); i++) {
            if (!writeCommand(commands[i])) break;
        }
        if (i == sizeof(commands)) break;
    }
    if (addressIndex == sizeof(addresses)) {
        gOledAddress = OLED_I2C_ADDRESS;
        return false;
    }
    memset(gFrameBuffer, 0, sizeof(gFrameBuffer));
    for (i = 0U; i < 8U; i++) if (!flushPage(i)) return false;
    gRefreshPage = 0U;
    return true;
}

void OLED_ShowTelemetry(int32_t distanceMm, int16_t leftPWM,
    int16_t rightPWM, int16_t leftRPM, int16_t rightRPM, bool online,
    bool runEnabled, uint32_t elapsedMs, bool timingStopped,
    uint8_t activeTaskId, uint32_t key1Count, uint32_t key2Count,
    const uint8_t grayStates[GRAY_SENSOR_COUNT])
{
    char line[18];
    uint32_t seconds;
    uint32_t milliseconds;
    uint8_t i;

    (void)leftPWM;
    (void)rightPWM;
    (void)leftRPM;
    (void)rightRPM;
    (void)online;
    (void)runEnabled;
    (void)timingStopped;
    (void)activeTaskId;

    if (gRefreshPage == 0U) {
        memset(gFrameBuffer, 0, sizeof(gFrameBuffer));
        if (distanceMm > 999999L) distanceMm = 999999L;
        if (distanceMm < -999999L) distanceMm = -999999L;
        (void)snprintf(line, sizeof(line), "X:%+07ldmm", (long)distanceMm);
        drawString16(0U, 0U, line);

        seconds = elapsedMs / 1000U;
        milliseconds = elapsedMs % 1000U;
        if (seconds > 999U) seconds = 999U;
        (void)snprintf(line, sizeof(line), "T:%03lu.%03lus",
            (unsigned long)seconds, (unsigned long)milliseconds);
        drawString16(1U, 0U, line);

        (void)snprintf(line, sizeof(line), "K1:%03lu K2:%03lu",
            (unsigned long)key1Count, (unsigned long)key2Count);
        drawString16(2U, 0U, line);

        line[0] = 'G';
        line[1] = ':';
        for (i = 0U; i < GRAY_SENSOR_COUNT; i++) {
            line[2U + i] = grayStates[i] ? '1' : '0';
        }
        line[2U + GRAY_SENSOR_COUNT] = '\0';
        drawString16(3U, 0U, line);
    }
    (void)flushPage(gRefreshPage);
    gRefreshPage = (uint8_t)((gRefreshPage + 1U) % 8U);
}
void OLED_ShowICM45686(const ICM45686_Data *data)
{
    char line[18];
    int32_t angle[3];
    const char *names[3] = {"ROLL", "PITCH", "YAW"};
    uint8_t i;

    if (data == NULL) return;

    if (gRefreshPage == 0U) {
        memset(gFrameBuffer, 0, sizeof(gFrameBuffer));
        (void)snprintf(line, sizeof(line), "ICM45686 %s",
            data->online ? (data->gyroBiasReady ? "OK" : "BIAS") : "ERR");
        drawString16(0U, 0U, line);
        angle[0] = data->rollMdeg; angle[1] = data->pitchMdeg; angle[2] = data->yawMdeg;
        for (i = 0U; i < 3U; i++) {
            int32_t value = angle[i];
            int32_t absValue = value < 0 ? -value : value;
            if (absValue > 180000) absValue = 180000;
            (void)snprintf(line, sizeof(line), "%s:%c%ld.%ld deg", names[i],
                value < 0 ? '-' : '+', (long)(absValue / 1000L),
                (long)((absValue % 1000L) / 100L));
            drawString16((uint8_t)(i + 1U), 0U, line);
        }
    }
    (void)flushPage(gRefreshPage);
    gRefreshPage = (uint8_t)((gRefreshPage + 1U) % 8U);
}
