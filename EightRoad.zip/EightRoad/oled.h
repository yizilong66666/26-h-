#ifndef OLED_H
#define OLED_H

#include <stdbool.h>
#include <stdint.h>

#include "gray_sensor.h"
#include "icm45686.h"

bool OLED_Init(void);
void OLED_ShowTelemetry(int32_t distanceMm, int16_t leftPWM,
    int16_t rightPWM, int16_t leftRPM, int16_t rightRPM, bool online,
    bool runEnabled, uint32_t elapsedMs, bool timingStopped,
    uint8_t activeTaskId, uint32_t key1Count, uint32_t key2Count,
    const uint8_t grayStates[GRAY_SENSOR_COUNT]);
/* 固定显示通信状态以及 Roll、Pitch、Yaw 三个欧拉角。 */
void OLED_ShowICM45686(const ICM45686_Data *data);

#endif
