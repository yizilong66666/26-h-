#include "speed_control.h"
#include "encoder.h"
#include "motor.h"

typedef struct {
    /* 保存的是尚未除以 KI 分母的积分量，保留整数计算精度。 */
    int32_t integralAccumulator;
} SpeedPIState;

static SpeedPIState gLeftPI;
static SpeedPIState gRightPI;
static int16_t gLeftTargetRPM;
static int16_t gRightTargetRPM;
static SpeedControlConfig gConfig;

static int16_t clampTarget(int16_t target)
{
    /* 转弯控制需要负转速，所以限幅必须关于 0 对称。 */
    if (target < -gConfig.maxTargetRPM) return -gConfig.maxTargetRPM;
    if (target > gConfig.maxTargetRPM) return gConfig.maxTargetRPM;
    return target;
}

static int16_t calculatePWM(int16_t targetRPM, int16_t measuredRPM,
    SpeedPIState *state)
{
    int16_t direction;
    int16_t targetMagnitude;
    int16_t measuredAlongTarget;
    int32_t error;
    int32_t feedforward;
    int32_t proportional;
    int32_t candidateIntegralAccumulator;
    int32_t integralPercent;
    int32_t output;

    if (targetRPM == 0) {
        state->integralAccumulator = 0;
        return 0;
    }
    /* PI 始终对“沿目标方向的速度幅值”运算，最后再恢复电机方向。 */
    direction = targetRPM > 0 ? 1 : -1;
    targetMagnitude = targetRPM > 0 ? targetRPM : (int16_t)-targetRPM;
    measuredAlongTarget = (int16_t)(measuredRPM * direction);

    error = (int32_t)targetMagnitude - measuredAlongTarget;
    /* 前馈负责提供接近目标转速所需的基础 PWM，PI 只补偿误差。 */
    feedforward = ((int32_t)targetMagnitude * gConfig.feedforwardPWMPercent) /
        gConfig.baseTargetRPM;
    proportional = (error * gConfig.kpNumerator) / gConfig.kpDenominator;
    candidateIntegralAccumulator = state->integralAccumulator +
        error * gConfig.kiNumerator;

    /* 先限制积分本身，避免长时间堵转后释放时出现巨大冲击。 */
    if (candidateIntegralAccumulator >
        gConfig.integralLimitPercent * gConfig.kiDenominator) {
        candidateIntegralAccumulator =
            gConfig.integralLimitPercent * gConfig.kiDenominator;
    }
    if (candidateIntegralAccumulator <
        -gConfig.integralLimitPercent * gConfig.kiDenominator) {
        candidateIntegralAccumulator =
            -gConfig.integralLimitPercent * gConfig.kiDenominator;
    }

    integralPercent = candidateIntegralAccumulator / gConfig.kiDenominator;
    output = feedforward + proportional + integralPercent;

    /* 仅当积分不会继续把输出推向饱和方向时才接纳本次积分。 */
    if (!((output > gConfig.maxPWMPercent && error > 0) ||
          (output < gConfig.minRunPWMPercent && error < 0))) {
        state->integralAccumulator = candidateIntegralAccumulator;
    }

    integralPercent = state->integralAccumulator / gConfig.kiDenominator;
    output = feedforward + proportional + integralPercent;
    if (output > gConfig.maxPWMPercent) output = gConfig.maxPWMPercent;
    if (output < gConfig.minRunPWMPercent)
        output = gConfig.minRunPWMPercent;
    return (int16_t)(output * direction);
}

void SpeedControl_Init(void)
{
    gLeftPI.integralAccumulator = 0;
    gRightPI.integralAccumulator = 0;
    gLeftTargetRPM = 0;
    gRightTargetRPM = 0;
}

void SpeedControl_Configure(const SpeedControlConfig *config)
{
    if (config == 0 || config->baseTargetRPM <= 0 ||
        config->maxTargetRPM <= 0 || config->kpDenominator <= 0 ||
        config->kiDenominator <= 0) {
        SpeedControl_Stop();
        return;
    }
    gConfig = *config;
    SpeedControl_Stop();
}

void SpeedControl_SetTargets(int16_t leftRPM, int16_t rightRPM)
{
    gLeftTargetRPM = clampTarget(leftRPM);
    gRightTargetRPM = clampTarget(rightRPM);
}

void SpeedControl_Update(void)
{
    int16_t leftPWM = calculatePWM(
        gLeftTargetRPM, Encoder_GetLeftRPM(), &gLeftPI);
    int16_t rightPWM = calculatePWM(
        gRightTargetRPM, Encoder_GetRightRPM(), &gRightPI);
    Motor_Set(leftPWM, rightPWM);
}

void SpeedControl_Stop(void)
{
    gLeftTargetRPM = 0;
    gRightTargetRPM = 0;
    gLeftPI.integralAccumulator = 0;
    gRightPI.integralAccumulator = 0;
    Motor_Stop();
}

int16_t SpeedControl_GetLeftTargetRPM(void) { return gLeftTargetRPM; }
int16_t SpeedControl_GetRightTargetRPM(void) { return gRightTargetRPM; }
