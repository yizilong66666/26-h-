#ifndef SPEED_CONTROL_H
#define SPEED_CONTROL_H

#include <stdint.h>

typedef struct {
    int16_t baseTargetRPM;
    int16_t maxTargetRPM;
    int16_t feedforwardPWMPercent;
    int16_t kpNumerator;
    int16_t kpDenominator;
    int16_t kiNumerator;
    int16_t kiDenominator;
    int16_t integralLimitPercent;
    int16_t maxPWMPercent;
    int16_t minRunPWMPercent;
} SpeedControlConfig;

void SpeedControl_Init(void);
void SpeedControl_Configure(const SpeedControlConfig *config);
void SpeedControl_SetTargets(int16_t leftRPM, int16_t rightRPM);
void SpeedControl_Update(void);
void SpeedControl_Stop(void);
int16_t SpeedControl_GetLeftTargetRPM(void);
int16_t SpeedControl_GetRightTargetRPM(void);

#endif
