#include "task1.h"
#include "line_task.h"
#include "task1_config.h"

/* Task1 的配置和运行状态只属于 Task1。 */
static const LineTaskConfig gTask1Config = {
    .motorOutputEnabled = TASK1_MOTOR_OUTPUT_ENABLE != 0U,
    .startupDelayMs = TASK1_STARTUP_DELAY_MS,
    .startupRampEnabled = TASK1_STARTUP_RAMP_ENABLE != 0U,
    .startupRampMs = TASK1_STARTUP_RAMP_MS,
    .trackKp = TASK1_TRACK_KP,
    .trackKd = TASK1_TRACK_KD,
    .baseTargetRPM = TASK1_BASE_TARGET_RPM,
    .maxTargetRPM = TASK1_MAX_TARGET_RPM,
    .minTargetRPM = TASK1_MIN_TARGET_RPM,
    .stopOnAllWhite = TASK1_STOP_ON_ALL_WHITE != 0U,
    .stopOnAllBlack = TASK1_STOP_ON_ALL_BLACK != 0U,
    .distanceStopEnabled = TASK1_DISTANCE_STOP_ENABLE != 0U,
    .distanceStopMm = TASK1_DISTANCE_STOP_MM,
    .speed = {
        .baseTargetRPM = TASK1_BASE_TARGET_RPM,
        .maxTargetRPM = TASK1_MAX_TARGET_RPM,
        .feedforwardPWMPercent = TASK1_SPEED_FEEDFORWARD_PWM,
        .kpNumerator = TASK1_SPEED_KP_NUMERATOR,
        .kpDenominator = TASK1_SPEED_KP_DENOMINATOR,
        .kiNumerator = TASK1_SPEED_KI_NUMERATOR,
        .kiDenominator = TASK1_SPEED_KI_DENOMINATOR,
        .integralLimitPercent = TASK1_SPEED_INTEGRAL_LIMIT,
        .maxPWMPercent = TASK1_MOTOR_MAX_PWM,
        .minRunPWMPercent = TASK1_MOTOR_MIN_RUN_PWM
    }
};
static LineTaskState gTask1State;

void Task1_Start(void)
{
    LineTask_Init(&gTask1State, &gTask1Config);
}

void Task1_Loop(const uint8_t grayStates[GRAY_SENSOR_COUNT], bool sensorOnline,
    uint32_t nowMs)
{
    LineTask_Run(&gTask1State, &gTask1Config, grayStates, sensorOnline, nowMs);
}

uint32_t Task1_GetElapsedMs(void)
{
    return LineTask_GetElapsedMs(&gTask1State);
}

bool Task1_IsDistanceStopped(void)
{
    return LineTask_IsDistanceStopped(&gTask1State);
}

uint32_t Task1_GetStartupDelayMs(void)
{
    return gTask1Config.startupDelayMs;
}
