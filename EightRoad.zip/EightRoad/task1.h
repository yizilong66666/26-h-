#ifndef TASK1_H
#define TASK1_H

#include "gray_sensor.h"
#include <stdbool.h>
#include <stdint.h>

void Task1_Start(void);
void Task1_Loop(const uint8_t grayStates[GRAY_SENSOR_COUNT], bool sensorOnline,
    uint32_t nowMs);
uint32_t Task1_GetStartupDelayMs(void);
uint32_t Task1_GetElapsedMs(void);
bool Task1_IsDistanceStopped(void);

#endif
