#ifndef TASK1_CONFIG_H
#define TASK1_CONFIG_H

/*
 * ============================================================================
 * Task1 参数控制区：当前已经调通的稳定参数快照
 * ============================================================================
 * 重要级别：★★★★★ 必须优先标定；★★★★ 影响明显；★★★ 功能或保护参数。
 * 调试原则：每次只改一个参数，编译下载后记录现象；建议新实验优先改 Task2。
 *
 * 完整调试顺序：
 * 0. 架空车轮并禁止电机输出；
 * 1. 在 app_config.h 确认灰度、电机和编码器方向；
 * 2. 标定基础目标转速与前馈 PWM；
 * 3. 先调速度 KP，再调速度 KI；
 * 4. 先调循迹 KP，再调循迹 KD；
 * 5. 最后设置最大/最小速度和停车条件。
 */

/* [步骤0][★★★★★] 0=禁止电机输出，1=允许运行。首次调试必须先设为 0。 */
#define TASK1_MOTOR_OUTPUT_ENABLE          (1U)
/* [步骤0][★★★] 上电静止等待时间，单位 ms；当前等待 1.5 秒后才开始控制。 */
#define TASK1_STARTUP_DELAY_MS             (1500U)
/* Task1 保持原有起步行为，不启用额外加速斜坡。 */
#define TASK1_STARTUP_RAMP_ENABLE          (0U)
#define TASK1_STARTUP_RAMP_MS              (0U)

/* [步骤2][★★★★★] 直线基础目标转速，单位 RPM；增大后整车速度提高。 */
#define TASK1_BASE_TARGET_RPM              (100)
/* [步骤2][★★★★★] 基础转速对应的开环 PWM 百分比；偏小起步慢，偏大易超调。 */
#define TASK1_SPEED_FEEDFORWARD_PWM        (23)

/*
 * [步骤3][★★★★★] 速度环比例系数 KP=分子/分母，当前为 1/20=0.05。
 * 增大 KP：速度跟随更快；过大会使轮速和 PWM 来回抖动。
 */
#define TASK1_SPEED_KP_NUMERATOR           (1)
#define TASK1_SPEED_KP_DENOMINATOR         (20)
/*
 * [步骤3][★★★★] 速度环积分系数 KI=分子/分母，当前为 1/220。
 * 增大 KI：更快消除长期转速误差；过大会慢周期振荡和停车前冲。
 */
#define TASK1_SPEED_KI_NUMERATOR           (1)
#define TASK1_SPEED_KI_DENOMINATOR         (220)
/* [步骤3][★★★] 积分项最多补偿的 PWM 百分点，限制堵转后的积分累积。 */
#define TASK1_SPEED_INTEGRAL_LIMIT         (25)

/*
 * [步骤4][★★★★★] 循迹比例系数：决定偏离黑线时的转向强度。
 * 增大后回线更快；过大会连续蛇形摆动。
 */
#define TASK1_TRACK_KP                     (2.5f)
/*
 * [步骤4][★★★★] 循迹微分系数：根据误差变化抑制摆动。
 * 增大可减小过冲；过大会在灰度跳变时突然抽动。
 */
#define TASK1_TRACK_KD                     (0.0f)

/* [步骤5][★★★★] 允许的最高目标转速，必须不小于基础转速。 */
#define TASK1_MAX_TARGET_RPM               (120)
/* [步骤5][★★★★] 过弯内轮最低目标转速；过高转不过弯，过低可能停转。 */
#define TASK1_MIN_TARGET_RPM               (20)
/* [步骤5][★★★★] 电机 PWM 上限，单位百分比；限制最高输出和机械冲击。 */
#define TASK1_MOTOR_MAX_PWM                (75)
/* [步骤5][★★★] 非零目标下的最小 PWM；按电机可靠起转点设置。 */
#define TASK1_MOTOR_MIN_RUN_PWM            (5)

/* [步骤5][★★★] 1=12 路全白停车；0=全白时继续使用当前循迹计算。 */
#define TASK1_STOP_ON_ALL_WHITE            (1U)
/* [步骤5][★★★] 1=12 路全黑停车；当前为 0，全黑时直行通过。 */
#define TASK1_STOP_ON_ALL_BLACK            (0U)
/* [步骤5][★★★★] 1=启用编码器距离停车；0=忽略距离，只按灰度条件运行。 */
#define TASK1_DISTANCE_STOP_ENABLE         (1U)
/* [步骤5][★★★★] 距离停车阈值，单位 mm；达到后锁定停车直到复位。 */
#define TASK1_DISTANCE_STOP_MM             (1500L)

#if TASK1_SPEED_KP_DENOMINATOR <= 0 || TASK1_SPEED_KI_DENOMINATOR <= 0
#error "Task1 速度 PI 分母必须大于 0"
#endif
#if TASK1_MIN_TARGET_RPM < 0 || TASK1_MIN_TARGET_RPM > TASK1_BASE_TARGET_RPM
#error "Task1 最小转速必须在 0 到基础转速之间"
#endif
#if TASK1_BASE_TARGET_RPM > TASK1_MAX_TARGET_RPM
#error "Task1 基础转速不能大于最大转速"
#endif

#endif
