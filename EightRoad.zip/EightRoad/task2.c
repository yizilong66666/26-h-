#include "task2.h"
#include "line_task.h"
#include "task2_config.h"

/*
 * Task2 有独立配置和独立状态。若以后需要完全不同的运行模式，
 * 只需在本文件重写 Task2_Loop，不需要修改 Task1。
 */
static const LineTaskConfig gTask2Config = {
    .motorOutputEnabled = TASK2_MOTOR_OUTPUT_ENABLE != 0U,
    .startupDelayMs = TASK2_STARTUP_DELAY_MS,
    .startupRampEnabled = TASK2_STARTUP_RAMP_ENABLE != 0U,
    .startupRampMs = TASK2_STARTUP_RAMP_MS,
    .trackKp = TASK2_TRACK_KP,
    .trackKd = TASK2_TRACK_KD,
    .baseTargetRPM = TASK2_BASE_TARGET_RPM,
    .maxTargetRPM = TASK2_MAX_TARGET_RPM,
    .minTargetRPM = TASK2_MIN_TARGET_RPM,
    .stopOnAllWhite = TASK2_STOP_ON_ALL_WHITE != 0U,
    .stopOnAllBlack = TASK2_STOP_ON_ALL_BLACK != 0U,
    .distanceStopEnabled = TASK2_DISTANCE_STOP_ENABLE != 0U,
    .distanceStopMm = TASK2_DISTANCE_STOP_MM,
    .speed = {
        .baseTargetRPM = TASK2_BASE_TARGET_RPM,
        .maxTargetRPM = TASK2_MAX_TARGET_RPM,
        .feedforwardPWMPercent = TASK2_SPEED_FEEDFORWARD_PWM,
        .kpNumerator = TASK2_SPEED_KP_NUMERATOR,
        .kpDenominator = TASK2_SPEED_KP_DENOMINATOR,
        .kiNumerator = TASK2_SPEED_KI_NUMERATOR,
        .kiDenominator = TASK2_SPEED_KI_DENOMINATOR,
        .integralLimitPercent = TASK2_SPEED_INTEGRAL_LIMIT,
        .maxPWMPercent = TASK2_MOTOR_MAX_PWM,
        .minRunPWMPercent = TASK2_MOTOR_MIN_RUN_PWM
    }
};
static LineTaskState gTask2State;

void Task2_Start(void)
{
    LineTask_Init(&gTask2State, &gTask2Config);
}

void Task2_Loop(const uint8_t grayStates[GRAY_SENSOR_COUNT], bool sensorOnline,
    uint32_t nowMs)
{
    LineTask_Run(&gTask2State, &gTask2Config, grayStates, sensorOnline, nowMs);
}

uint32_t Task2_GetElapsedMs(void)
{
    return LineTask_GetElapsedMs(&gTask2State);
}

bool Task2_IsDistanceStopped(void)
{
    return LineTask_IsDistanceStopped(&gTask2State);
}

uint32_t Task2_GetStartupDelayMs(void)
{
    return gTask2Config.startupDelayMs;
}
