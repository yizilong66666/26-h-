#ifndef TASK2_H
#define TASK2_H

#include "gray_sensor.h"
#include <stdbool.h>
#include <stdint.h>

void Task2_Start(void);
void Task2_Loop(const uint8_t grayStates[GRAY_SENSOR_COUNT], bool sensorOnline,
    uint32_t nowMs);
uint32_t Task2_GetStartupDelayMs(void);
uint32_t Task2_GetElapsedMs(void);
bool Task2_IsDistanceStopped(void);

#endif
