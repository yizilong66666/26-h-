#ifndef TASK2_CONFIG_H
#define TASK2_CONFIG_H

/*
 * ============================================================================
 * Task2 参数控制区：独立实验参数，不会修改 Task1
 * ============================================================================
 * 重要级别：★★★★★ 必须优先标定；★★★★ 影响明显；★★★ 功能或保护参数。
 *
 * 完整调试顺序：
 * 0. 架空车轮，TASK2_MOTOR_OUTPUT_ENABLE 先设为 0；
 * 1. 在 app_config.h 确认灰度、电机和编码器方向；
 * 2. 低速标定基础目标 RPM 和前馈 PWM；
 * 3. KI 暂设 0，先调速度 KP，再恢复并逐步增加 KI；
 * 4. KD 暂设 0，先调循迹 KP，再逐步增加 KD；
 * 5. 最后调整限速、全白/全黑和距离停车条件。
 */

/* [步骤0][★★★★★] 0=禁止电机输出，1=允许运行。首次测试必须先设为 0。 */
#define TASK2_MOTOR_OUTPUT_ENABLE          (1U)
/* [步骤0][★★★] 上电静止等待时间，单位 ms；当前为 1500 ms。 */
#define TASK2_STARTUP_DELAY_MS             (1000U)
/* [步骤0][★★★★★] 起步加速斜坡开关；1=从 0 RPM 缓慢升速，0=直接给目标速度。 */
#define TASK2_STARTUP_RAMP_ENABLE          (1U)
/* [步骤0][★★★★★] 斜坡时间，单位 ms；当前 1200 ms，增大可让起步更柔和。 */
#define TASK2_STARTUP_RAMP_MS              (1200U)

/* [步骤2][★★★★★] 直线基础目标转速，单位 RPM；Task2 主要车速参数。 */
#define TASK2_BASE_TARGET_RPM              (65)
/* [步骤2][★★★★★] 达到基础转速大致需要的 PWM；先开环实测，再调 PI。 */
#define TASK2_SPEED_FEEDFORWARD_PWM        (20)

/*
 * [步骤3][★★★★★] 速度环 KP=分子/分母，当前 1/20=0.05。
 * 增大后响应更快；轮速快速振荡或声音发颤时应减小。
 */
#define TASK2_SPEED_KP_NUMERATOR           (1)
#define TASK2_SPEED_KP_DENOMINATOR         (20)
/*
 * [步骤3][★★★★] 速度环 KI=分子/分母，当前 1/220。
 * 用来消除左右轮长期静差；调试 KP 时可暂时把分子设为 0。
 */
#define TASK2_SPEED_KI_NUMERATOR           (1)
#define TASK2_SPEED_KI_DENOMINATOR         (220)
/* [步骤3][★★★] 积分最多补偿的 PWM 百分点；通常不应盲目增大。 */
#define TASK2_SPEED_INTEGRAL_LIMIT         (25)

/*
 * [步骤4][★★★★★] 循迹 KP：黑线偏离中心后产生多大的左右轮差速。
 * 转弯迟钝就增大，连续蛇形就减小。
 */
#define TASK2_TRACK_KP                     (4.0f)
/*
 * [步骤4][★★★★] 循迹 KD：抑制误差快速变化造成的过冲。
 * 摆动明显可适当增加；灰度跳格时猛抽则减小。
 */
#define TASK2_TRACK_KD                     (0.0f)

/* [步骤5][★★★★] 最大目标转速，必须 >= 基础目标转速。 */
#define TASK2_MAX_TARGET_RPM               (120)
/* [步骤5][★★★★] 内轮最低转速；越低转弯越急，但可能进入电机死区。 */
#define TASK2_MIN_TARGET_RPM               (20)
/* [步骤5][★★★★] PWM 输出上限，单位百分比；先保守设置再逐步提高。 */
#define TASK2_MOTOR_MAX_PWM                (75)
/* [步骤5][★★★] 电机可靠起转所需的最小 PWM 百分比。 */
#define TASK2_MOTOR_MIN_RUN_PWM            (5)

/* [步骤5][★★★] 1=全白停车；0=全白时不使用该停车条件。 */
#define TASK2_STOP_ON_ALL_WHITE            (1U)
/* [步骤5][★★★] 1=全黑停车；0=全黑时按零误差直行通过。 */
#define TASK2_STOP_ON_ALL_BLACK            (0U)
/* [步骤5][★★★★] 是否启用编码器累计距离停车。 */
#define TASK2_DISTANCE_STOP_ENABLE         (1U)
/* [步骤5][★★★★] 停车距离，单位 mm；达到后锁存，复位后重新计程。 */
#define TASK2_DISTANCE_STOP_MM             (5900L)

#if TASK2_SPEED_KP_DENOMINATOR <= 0 || TASK2_SPEED_KI_DENOMINATOR <= 0
#error "Task2 速度 PI 分母必须大于 0"
#endif
#if TASK2_MIN_TARGET_RPM < 0 || TASK2_MIN_TARGET_RPM > TASK2_BASE_TARGET_RPM
#error "Task2 最小转速必须在 0 到基础转速之间"
#endif
#if TASK2_BASE_TARGET_RPM > TASK2_MAX_TARGET_RPM
#error "Task2 基础转速不能大于最大转速"
#endif

#endif
