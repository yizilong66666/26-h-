#include "task3.h"
#include "line_task.h"
#include "task3_config.h"

/* Task3 的配置和运行状态完全独立，初始数值与 Task1 相同。 */
static const LineTaskConfig gTask3Config = {
    .motorOutputEnabled = TASK3_MOTOR_OUTPUT_ENABLE != 0U,
    .startupDelayMs = TASK3_STARTUP_DELAY_MS,
    .startupRampEnabled = TASK3_STARTUP_RAMP_ENABLE != 0U,
    .startupRampMs = TASK3_STARTUP_RAMP_MS,
    .trackKp = TASK3_TRACK_KP,
    .trackKd = TASK3_TRACK_KD,
    .baseTargetRPM = TASK3_BASE_TARGET_RPM,
    .maxTargetRPM = TASK3_MAX_TARGET_RPM,
    .minTargetRPM = TASK3_MIN_TARGET_RPM,
    .stopOnAllWhite = TASK3_STOP_ON_ALL_WHITE != 0U,
    .stopOnAllBlack = TASK3_STOP_ON_ALL_BLACK != 0U,
    .distanceStopEnabled = TASK3_DISTANCE_STOP_ENABLE != 0U,
    .distanceStopMm = TASK3_DISTANCE_STOP_MM,
    .speed = {
        .baseTargetRPM = TASK3_BASE_TARGET_RPM,
        .maxTargetRPM = TASK3_MAX_TARGET_RPM,
        .feedforwardPWMPercent = TASK3_SPEED_FEEDFORWARD_PWM,
        .kpNumerator = TASK3_SPEED_KP_NUMERATOR,
        .kpDenominator = TASK3_SPEED_KP_DENOMINATOR,
        .kiNumerator = TASK3_SPEED_KI_NUMERATOR,
        .kiDenominator = TASK3_SPEED_KI_DENOMINATOR,
        .integralLimitPercent = TASK3_SPEED_INTEGRAL_LIMIT,
        .maxPWMPercent = TASK3_MOTOR_MAX_PWM,
        .minRunPWMPercent = TASK3_MOTOR_MIN_RUN_PWM
    }
};
static LineTaskState gTask3State;

void Task3_Start(void)
{
    LineTask_Init(&gTask3State, &gTask3Config);
}

void Task3_Loop(const uint8_t grayStates[GRAY_SENSOR_COUNT], bool sensorOnline,
    uint32_t nowMs)
{
    LineTask_Run(&gTask3State, &gTask3Config, grayStates, sensorOnline, nowMs);
}

uint32_t Task3_GetElapsedMs(void)
{
    return LineTask_GetElapsedMs(&gTask3State);
}

bool Task3_IsDistanceStopped(void)
{
    return LineTask_IsDistanceStopped(&gTask3State);
}

uint32_t Task3_GetStartupDelayMs(void)
{
    return gTask3Config.startupDelayMs;
}
