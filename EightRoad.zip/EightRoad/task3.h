#ifndef TASK3_H
#define TASK3_H

#include "gray_sensor.h"
#include <stdbool.h>
#include <stdint.h>

void Task3_Start(void);
void Task3_Loop(const uint8_t grayStates[GRAY_SENSOR_COUNT], bool sensorOnline,
    uint32_t nowMs);
uint32_t Task3_GetStartupDelayMs(void);
uint32_t Task3_GetElapsedMs(void);
bool Task3_IsDistanceStopped(void);

#endif
