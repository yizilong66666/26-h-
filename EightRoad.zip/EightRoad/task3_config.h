#ifndef TASK3_CONFIG_H
#define TASK3_CONFIG_H

/*
 * ============================================================================
 * Task3 参数控制区：初始参数复制 Task1，后续可独立修改
 * ============================================================================
 * 重要级别：★★★★★ 必须优先标定；★★★★ 影响明显；★★★ 功能或保护参数。
 *
 * 完整调试顺序：
 * 0. 架空车轮，TASK3_MOTOR_OUTPUT_ENABLE 先设为 0；
 * 1. 在 app_config.h 确认灰度、电机和编码器方向；
 * 2. 标定基础目标 RPM 和前馈 PWM；
 * 3. 先调速度 KP，再调速度 KI；
 * 4. 先调循迹 KP，再调循迹 KD；
 * 5. 最后调整限速和停车条件。
 */

/* [步骤0][★★★★★] 0=禁止电机输出，1=允许运行。首次测试必须先设为 0。 */
#define TASK3_MOTOR_OUTPUT_ENABLE          (1U)
/* [步骤0][★★★] 上电静止等待时间，单位 ms；该时间计入最终总时间。 */
#define TASK3_STARTUP_DELAY_MS             (1500U)
/* [步骤0][★★★★★] 起步加速斜坡开关；1=从 0 RPM 缓慢升速。 */
#define TASK3_STARTUP_RAMP_ENABLE          (1U)
/* [步骤0][★★★★★] 斜坡时间，单位 ms；当前 1200 ms，越大起步越柔和。 */
#define TASK3_STARTUP_RAMP_MS              (1200U)

/* [步骤2][★★★★★] 直线基础目标转速，单位 RPM；增大后整车速度提高。 */
#define TASK3_BASE_TARGET_RPM              (160)
/* [步骤2][★★★★★] 基础转速对应的开环 PWM；偏小起步慢，偏大易超调。 */
#define TASK3_SPEED_FEEDFORWARD_PWM        (20)

/* [步骤3][★★★★★] 速度环 KP=分子/分母，当前 1/20=0.05。 */
#define TASK3_SPEED_KP_NUMERATOR           (1)
#define TASK3_SPEED_KP_DENOMINATOR         (20)
/* [步骤3][★★★★] 速度环 KI=分子/分母，当前 1/220；消除长期转速误差。 */
#define TASK3_SPEED_KI_NUMERATOR           (1)
#define TASK3_SPEED_KI_DENOMINATOR         (220)
/* [步骤3][★★★] 积分项最多补偿的 PWM 百分点，防止堵转积分累积。 */
#define TASK3_SPEED_INTEGRAL_LIMIT         (25)

/* [步骤4][★★★★★] 循迹 KP；增大后回线更快，过大会连续蛇形。 */
#define TASK3_TRACK_KP                     (20.5f)
/* [步骤4][★★★★] 循迹 KD；抑制过冲，过大会在灰度跳变时抽动。 */
#define TASK3_TRACK_KD                     (0.0f)

/* [步骤5][★★★★] 允许的最高目标转速，必须不小于基础转速。 */
#define TASK3_MAX_TARGET_RPM               (120)
/* [步骤5][★★★★] 过弯内轮最低目标转速；过高转不过弯，过低可能停转。 */
#define TASK3_MIN_TARGET_RPM               (20)
/* [步骤5][★★★★] 电机 PWM 上限，单位百分比。 */
#define TASK3_MOTOR_MAX_PWM                (75)
/* [步骤5][★★★] 非零目标下的最小 PWM，按电机可靠起转点设置。 */
#define TASK3_MOTOR_MIN_RUN_PWM            (5)

/* [步骤5][★★★] 1=12 路全白停车；0=不使用全白停车条件。 */
#define TASK3_STOP_ON_ALL_WHITE            (1U)
/* [步骤5][★★★] 1=12 路全黑停车；当前为 0，全黑时直行通过。 */
#define TASK3_STOP_ON_ALL_BLACK            (0U)
/* [步骤5][★★★★] 1=启用编码器距离停车。 */
#define TASK3_DISTANCE_STOP_ENABLE         (1U)
/* [步骤5][★★★★] 停车距离，单位 mm；停车后锁存从上电开始的总时间。 */
#define TASK3_DISTANCE_STOP_MM             (5900L)

#if TASK3_SPEED_KP_DENOMINATOR <= 0 || TASK3_SPEED_KI_DENOMINATOR <= 0
#error "Task3 速度 PI 分母必须大于 0"
#endif
#if TASK3_MIN_TARGET_RPM < 0 || TASK3_MIN_TARGET_RPM > TASK3_BASE_TARGET_RPM
#error "Task3 最小转速必须在 0 到基础转速之间"
#endif
#if TASK3_BASE_TARGET_RPM > TASK3_MAX_TARGET_RPM
#error "Task3 基础转速不能大于最大转速"
#endif

#endif
