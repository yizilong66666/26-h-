#ifndef TASK_PROFILE_H
#define TASK_PROFILE_H

#include "gray_sensor.h"
#include "speed_control.h"
#include <stdbool.h>
#include <stdint.h>

/* 一套任务的全部循迹参数。Task1 和 Task2 各保存一份，互不共用。 */
typedef struct {
    bool motorOutputEnabled;
    uint32_t startupDelayMs;
    bool startupRampEnabled;
    uint32_t startupRampMs;
    float trackKp;
    float trackKd;
    int16_t baseTargetRPM;
    int16_t maxTargetRPM;
    int16_t minTargetRPM;
    bool stopOnAllWhite;
    bool stopOnAllBlack;
    bool distanceStopEnabled;
    int32_t distanceStopMm;
    SpeedControlConfig speed;
} LineTaskConfig;

/* 每个任务拥有自己的历史误差和停车锁存，切换任务不会继承另一任务的状态。 */
typedef struct {
    int16_t lastError;
    bool distanceStopLatched;
    /* 从上电开始累计；编码器距离停车后锁存，不再随系统时钟增加。 */
    uint32_t elapsedMs;
} LineTaskState;

#endif
