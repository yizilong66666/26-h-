#ifndef TASK_SELECT_H
#define TASK_SELECT_H

/*
 * 当前没有按键，因此在这里用软件选择任务：
 * 1 = Task1；2 = Task2；3 = Task3。
 */
#define ACTIVE_TASK_ID                    (3U)

#if ACTIVE_TASK_ID != 1U && ACTIVE_TASK_ID != 2U && ACTIVE_TASK_ID != 3U
#error "ACTIVE_TASK_ID 只能设置为 1、2 或 3"
#endif

#endif
