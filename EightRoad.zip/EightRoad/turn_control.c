#include "turn_control.h"
#include "app_config.h"
#include "icm45686.h"
#include "speed_control.h"

/* 非阻塞转弯状态：由 5 ms 主控制节拍反复调用，不在函数内等待。 */
static bool gActive;
static bool gSucceeded;
static int32_t gTargetMdeg;
static uint32_t gStartMs;
static uint16_t gSettleCount;

void TurnControl_Init(void)
{
    gActive = false;
    gSucceeded = false;
    gTargetMdeg = 0;
    gStartMs = 0U;
    gSettleCount = 0U;
}

bool TurnControl_Start(int32_t targetMdeg)
{
    /* 限制到一圈以内；小于容差的命令没有实际控制意义。 */
    if (gActive || targetMdeg < -180000L || targetMdeg > 180000L ||
        (targetMdeg > -TURN_TOLERANCE_MDEG && targetMdeg < TURN_TOLERANCE_MDEG)) {
        return false;
    }
    /* 先清除上一段行驶的 PI 积分，再把本次起始航向定义为 0 度。 */
    SpeedControl_Stop();
    ICM45686_ResetRelativeYaw();
    gTargetMdeg = targetMdeg;
    gStartMs = 0U;
    gSettleCount = 0U;
    gSucceeded = false;
    gActive = true;
    return true;
}

void TurnControl_Update(int32_t yawMdeg, bool gyroReady, uint32_t nowMs)
{
    int32_t error;
    int16_t speed;
    if (!gActive) return;
    if (gStartMs == 0U) gStartMs = nowMs;
    /* 传感器离线或动作超时都立即停机，禁止无反馈持续旋转。 */
    if (!gyroReady || (nowMs - gStartMs) > TURN_TIMEOUT_MS) {
        TurnControl_Cancel();
        return;
    }
    error = gTargetMdeg - yawMdeg;
    /* 必须连续多个控制周期落在容差内，避免仅靠惯性瞬间穿过目标就判成功。 */
    if (error >= -TURN_TOLERANCE_MDEG && error <= TURN_TOLERANCE_MDEG) {
        SpeedControl_Stop();
        if (++gSettleCount >= TURN_SETTLE_COUNT) {
            gActive = false;
            gSucceeded = true;
        }
        return;
    }
    gSettleCount = 0U;
    /* 远端快速接近，进入减速区后低速收尾，降低制动过冲。 */
    speed = (error > -TURN_SLOWDOWN_MDEG && error < TURN_SLOWDOWN_MDEG) ?
        TURN_SLOW_RPM : TURN_FAST_RPM;
    /* 左右轮反向等速实现原地转向；正目标按约定为逆时针。 */
    if (error > 0) SpeedControl_SetTargets((int16_t)-speed, speed);
    else SpeedControl_SetTargets(speed, (int16_t)-speed);
}

bool TurnControl_IsActive(void) { return gActive; }
bool TurnControl_Succeeded(void) { return gSucceeded; }

void TurnControl_Cancel(void)
{
    /* 取消与故障使用同一安全出口：清状态、清 PI、立即关闭电机。 */
    gActive = false;
    gSucceeded = false;
    gSettleCount = 0U;
    SpeedControl_Stop();
}
