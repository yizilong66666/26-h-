#ifndef TURN_CONTROL_H
#define TURN_CONTROL_H

#include <stdbool.h>
#include <stdint.h>

void TurnControl_Init(void);
/*
 * 启动一次非阻塞原地转弯。正角度为逆时针，负角度为顺时针；
 * 单位为毫度，合法范围 -180000~+180000，成功接收命令返回 true。
 */
bool TurnControl_Start(int32_t targetMdeg);
/* 由 5 ms 主控制节拍调用；yawMdeg 使用 [-180°, +180°] 的相对偏航角。 */
void TurnControl_Update(int32_t yawMdeg, bool gyroReady, uint32_t nowMs);
/* 动作进行中返回 true；此时主程序不应同时运行灰度循迹。 */
bool TurnControl_IsActive(void);
/* 最近一次动作正常到角返回 true，取消、超时或失联返回 false。 */
bool TurnControl_Succeeded(void);
/* 紧急取消当前动作，清除速度 PI 并立即停机。 */
void TurnControl_Cancel(void);

#endif
